#!/bin/bash
. ~/PSConfEU/demo-magic/demo-magic.sh
. /usr/bin/virtualenvwrapper.sh
DEMO_PROMPT="${GREEN}➜ ${CYAN}[\t] ${RED}⌘  > "
TYPE_SPEED=50
clear
cd ~
p "${GREEN}# Using SSL - we have to change endpoint"
pe 'cat bin/withSsl'
p "${GREEN}# The problem: CA is not easy to configure... "
pe 'withSsl ls'
wait
clear
p "${GREEN}# Three options:"
p "${GREEN}# -- ignore cert validation"
pe 'workon ignore'
pe 'which withSsl.py | xargs cat'
pe 'ls -las "${VIRTUAL_ENV}/lib/python2.7/site-packages/requests/cacert.pem"'
pe 'withSsl.py ls'
wait
clear
p "${GREEN}# -- modify requests and add our CA"
pe 'workon requests'
pe 'which withSsl.py | xargs cat'
pe 'ls -las "${VIRTUAL_ENV}/lib/python2.7/site-packages/requests/cacert.pem"'
pe 'withSsl.py ls'
wait
clear
p "${GREEN}# -- modify pywinrm to allow seperate cert"
pe 'workon pywinrm'
pe 'which withSsl.py | xargs cat'
pe 'ls -las "${VIRTUAL_ENV}/lib/python2.7/site-packages/requests/cacert.pem"'
pe 'withSsl.py ls'
wait
clear
p "${RED}# Now that we have that one covered - let's look at delegation"
p "${GREEN}# We will login as a different user - our BOFH - first..."
pe 'kdestroy'
pe 'kinit BOFH@MONAD.NET'
pe 'klist'
p "${GREEN}# If we try to do something on DC now..."
pe 'withSsl.py icm dc { hostname }'
p "${GREEN}# But fortunatelly - we can use JEA endpoint instead!"
pe 'withSsl.py icm dc2 -ConfigurationName DnsAdmin { gcm }'
pe 'withSsl.py icm dc2 -Config DnsAdmin { Add-ARecord -? }'
pe 'withSsl.py icm dc2 -Config DnsAdmin { Add-ARecord psconfeu 192.168.7.140 }'
pe 'nslookup psconfeu.monad.net 192.168.7.1'
wait
clear
p "${GREEN}# We can allow commands that can mess things up too.... Just be careful! ;)"
pe 'withSsl.py icm dc2 -Config DnsAdmin { Remove-ARecord psconfeu 192.168.7.140 }'
p "${GREEN}# To make it more convenient - we can wrap python around it and expose as a single command"
pe 'cat ~/bin/adda | less'
pe 'adda --help'
p "${GREEN}# Let's see it in action!"
pe 'adda -n PSRocks -i 192.168.7.150'
pe 'nslookup PSRocks.monad.net 192.168.7.1'