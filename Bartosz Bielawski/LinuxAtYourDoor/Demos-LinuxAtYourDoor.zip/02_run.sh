#!/bin/bash
. ~/PSConfEU/demo-magic/demo-magic.sh
DEMO_PROMPT="${GREEN}➜ ${CYAN}[\t] ${RED}⌘  > "
TYPE_SPEED=50
clear
cd ~
p "${GREEN}# Let's take a look at basic scripts first"
pe 'cat bin/simpleWinRM'
p "${GREEN}# But before we run it - we will need to run kinit"
pe 'kinit bielawb@MONAD.NET'
p "${GREEN}# Mind CAPS in domain - it's not me being rude, it's required..."
wait
clear
p "${GREEN}# Time to give ls a try..."
pe 'simpleWinRM ls'
p "${GREEN}# But double-hop can bite us here too..."
pe 'simpleWinRM icm dc { hostname }'
p "${GREEN}# To fix it - we need to add kerberos_delegation = True...."
pe 'grep delegation bin/delegatedWinRM'
pe 'delegatedWinRM icm dc { hostname }'
wait
clear
p "${RED}# Issue - length of the command!"
p "${GREEN}# When we run shorter script - all works fine..."
pe 'runFewTimes 300 Get-Date\;'
p "${GREEN}# When we run something a bit longer - fails..."
pe 'runFewTimes 400 Get-Date\;'
p "${GREEN}# Easiest solution - have a script on the remote box"
pe 'simpleWinRM cat demo-pywinrm/WindowsScript/loremIpsum.ps1 \| measure -character'
p "${GREEN}# Our script is not very interesting, but still - way longer. And it works just fine"
pe 'runFewTimes 1 ./demo-pywinrm/WindowsScript/loremIpsum.ps1'
wait
clear
p "${RED}# Issue - data not protected!"
p "${GREEN}# Kerberos helps with password protection, but leaves data plain-text"
p "${GREEN}# Simple tcpdump and we can see secrets send back from winrm..."
pe 'cat ~/bin/decodeWinRM'
sudo echo dupa > /dev/null
pe 'decodeWinRM&'
pe 'simpleWinRM echo m@ypr0tectedData'
p "${GREEN}# To solve it - we can use SSL... But first, we need to configure our Windows node."
pe 'xfreerdp -g 1800x900 -u bielawb@monad.net jumpbox.monad.net'
