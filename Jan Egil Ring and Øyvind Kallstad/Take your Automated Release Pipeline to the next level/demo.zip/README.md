# PSConf EU - Automated Release Pipeline

[![CircleCI](https://circleci.com/gh/CrayonAS/psconfeu.automated_release_pipeline.svg?style=svg&circle-token=cf1f9f4615d075439bdf9bb2953376f930cf2602)](https://circleci.com/gh/CrayonAS/psconfeu.automated_release_pipeline)

Demo repository for Automated Release Pipeline talk at PowerShell Conference Europe 2017 - Jan Egil Ring &amp; Øyvind Kallstad

This demo is made to showcase multi-cloud deployment solutions, with automatic failover to other cloud in case of failure.

## Prerequisites

- Docker (local drive where this repository is located must be shared)
- On Windows: PowerShell
- A Service Principal in Azure AD
- An Access Key in AWS
- SSH Key imported into AWS

## Configuration

Overall project configurations is set in the _app.config.json_ file.

Deployment configurations are located in the _deployments_ folder, in the form of several json files with parameter settings for the deployment templates used for deploying resources to Azure and AWS.

The server setup of the CoreOS server being built is configured through a Cloud-Config file located in the _configs_ folder.

CI configuration is done through the _circle.yml_ file in the root of this repository.

## Continous Deployment

[CircleCI](https://circleci.com/docs/1.0/introduction/)   acts as a platform for both Continuous Integration and Continuous Deployment in this project. One of the main reasons this platform is chosen, is it's support for Linux (Ubuntu) and ease of use.  
CircleCI infers many settings automatically, but it is also possible to make custom [configuration](https://circleci.com/docs/1.0/configuration/)   through the web UI or by setting up a 
circle.yml file in the project’s root directory. If this file exists, CircleCI will read it each time it runs a build.  

If all tests in the file .\tests\app.config.tests.sh, Circle CI will trigger a deployment based on the settings in the project configuration file.  

## Automatic Failover

Automatic failover is done by using the following mechanisms:

- Azure Application Insights
- Azure Automation
- Azure DNS

An alert is raised in Application Insights if the web app's DNS name is unavailable. The alert will trigger a webhook which starts a runbook in Azure Automation. The runbook will change the web app's DNS name to the VM running in Azure if the DNS name is currently pointing to the VM running in AWS and vice versa.

### Active/Active deployment

A VM running the web app is running on both Azure and AWS. This allows for a fast failover since the service is already ready on a different IP address.

### Active/Passive deployment

Not implemented yet

### Single Cloud deployment

Not implemented yet

## Build Docker image for AWS & Azure CLI

A custom docker image is included that lets you use both Azure CLI 2.0 and AWS CLI from the same environment. This image must be built locally before you can start local deployment.

When run in the docker folder:

```bash
docker build -t "cloudcli:dockerfile" .
```

**Note** to run this image interactively:

```bash
docker run --rm -it cloudcli:dockerfile /bin/sh
```

## Manual Build

- Change the *ActiveCloud* setting in app.config.json to to the preferred cloud provider (Azure|AWS).
- Change the *Mode* setting to the preferred mode (SingleCloud|ActivePassive|ActiveActive).

Run the deploy script:

### On Windows

```PowerShell
.\run.ps1 deploy <AzureUsername> <AzurePassword> <AzureTennantId> <AwsUsername> <AwsPassword>
```

### On Linux

```Shell
./run.sh deploy <AzureUsername> <AzurePassword> <AzureTennantId> <AwsUsername> <AwsPassword>
```

## Teardown

To delete all resources in both Azure and AWS, use the teardown script:

### On Windows

```PowerShell
.\run.ps1 teardown <AzureUsername> <AzurePassword> <AzureTennantId> <AwsUsername> <AwsPassword>
```

### On Linux

```Shell
./run.sh teardown <AzureUsername> <AzurePassword> <AzureTennantId> <AwsUsername> <AwsPassword>
```
