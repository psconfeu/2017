#!/bin/bash

usage() {
    echo "Usage: ./run.sh [SCRIPT] <AzureUsername> <AzurePassword> <AzureTenantId> <AwsUsername> <AwsPassword>"
    echo "Start script in Docker container"
}

# if less than five arguments supplied, display usage
if [  $# -le 5 ]
then
    usage
    exit 1
fi

# check whether user have supplied -h or --help . If yes display usage
if [[ ( $# == "--help") ||  $# == "-h" ]]
then
    usage
    exit 0
fi

docker run --rm -it -v ${PWD}:/local -w /local cloudcli:dockerfile /bin/bash -c "./scripts/$1.sh $2 $3 $4 $5 $6"