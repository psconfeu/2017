#!/bin/bash

SECONDS=0

# Read helper functions
source ./scripts/functions.sh

# Save arguments
AZURE_USER=$1
AZURE_PW=$2
AZURE_TENANT=$3
AWS_USER=$4
AWS_PW=$5

# Read config
APP_CONFIG=$(cat ./app.config.json)
MODE=$(echo "$APP_CONFIG" | jq .Mode -r)
CLOUD=$(echo "$APP_CONFIG" | jq .ActiveCloud -r)
AZURE_LOCATION=$(echo "$APP_CONFIG" | jq .AzureLocation -r)
AWS_LOCATION=$(echo "$APP_CONFIG" | jq .AWSLocation -r)
AZURE_RESOURCE_GROUP=$(echo "$APP_CONFIG" | jq .AzureResourceGroup -r)

# Set up authentication to Azure
AZ_LOGIN=$(az login --username $AZURE_USER --password $AZURE_PW --tenant $AZURE_TENANT --service-principal)
echo "Authenticated to Azure" | adddate

# Set up environment for AWS
aws configure set aws_access_key_id $AWS_USER
aws configure set aws_secret_access_key $AWS_PW
aws configure set default.region $AWS_LOCATION
echo "Environment set up for AWS" | adddate

# Delete the AWS stack
aws cloudformation delete-stack --stack-name 'GitLab'
echo "Deleted AWS stack" | adddate

# Remove resources in Azure
AZ_DELETE=$(az group delete -n ${AZURE_RESOURCE_GROUP} --no-wait -y)
echo "Deleting Azure Resource Group" | adddate

# Remove DNS entries
AZ_DNS_DEL=$(az network dns record-set a delete -n 'gitlab' -g 'psconfeu2017demo' -z 'demo.powershell.no' -y)
AZ_DNS_DEL=$(az network dns record-set a delete -n 'aws-gitlab' -g 'psconfeu2017demo' -z 'demo.powershell.no' -y)
AZ_DNS_DEL=$(az network dns record-set a delete -n 'azure-gitlab' -g 'psconfeu2017demo' -z 'demo.powershell.no' -y)
echo "Deleted AzureDNS entries" | adddate