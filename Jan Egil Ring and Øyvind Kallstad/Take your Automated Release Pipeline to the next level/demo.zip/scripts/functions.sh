#!/bin/bash

convertsecs() {
    ((h=${1}/3600))
    ((m=(${1}%3600)/60))
    ((s=${1}%60))
    printf "%02d:%02d:%02d\n" $h $m $s
}

adddate() {
    while IFS= read -r line; do
        echo "$(date +"%Y-%m-%d %R:%S") $line"
    done
}

deployToAzure() {

    echo "Deploying to Azure" | adddate

    # Create Resource Group if it doesn't already exist
    RG_RESULT=$(az group exists -n ${AZURE_RESOURCE_GROUP})
    if [ ${RG_RESULT} != 'true' ]
    then
        echo "Creating Resource Group: ${AZURE_RESOURCE_GROUP}" | adddate
        RG_CREATE=$(az group create -n ${AZURE_RESOURCE_GROUP} -l ${AZURE_LOCATION})
    else
        echo "Resource Group '${AZURE_RESOURCE_GROUP}' already exist" | adddate
    fi

    # Deploying resources
    echo $APP_CONFIG | jq -c '.resources[]? | select(.deploy)' | while read RESOURCE; do

        COMMENT=$(echo "$RESOURCE" | jq -r .comment)
        TEMPLATE=$(echo "$RESOURCE" | jq -r .templateFileAzure)
        PARAMETERS=$(echo "$RESOURCE" | jq -r .parametersFileAzure)
        CUSTOMDATA=$(echo "$RESOURCE" | jq -r .customDataFile)

        echo "Deploying ${COMMENT}" | adddate

        # If custom data is used
        if [ ${CUSTOMDATA} != null ]
        then
            echo "Deploying with CustomData" | adddate

            # Read and base64 encode custom data
            CUSTOM_DATA="$(cat ${CUSTOMDATA} | openssl enc -base64 | sed ':a;N;$!ba;s/\n//g')"

            echo "Using template: ${TEMPLATE}" | adddate
            echo "Using parameter file: ${PARAMETERS}" | adddate
            echo "Deployment start" | adddate

            AZ_DEPLOY=$(az group deployment create \
                --resource-group ${AZURE_RESOURCE_GROUP} \
                --name 'AutomaticDeployment' \
                --template-file ${TEMPLATE} \
                --parameters "@$PARAMETERS" \
                --parameters "{\"customData\":{\"value\":\"$CUSTOM_DATA\"}}" \
                --mode 'incremental')

            echo "Deployment end" | adddate

        else
            echo "Using template: ${TEMPLATE}" | adddate
            echo "Using parameter file: ${PARAMETERS}" | adddate
            echo "Deployment start" | adddate

            AZ_DEPLOY=$(az group deployment create \
                --resource-group ${AZURE_RESOURCE_GROUP} \
                --name 'AutomaticDeployment' \
                --template-file ${TEMPLATE} \
                --parameters "@$PARAMETERS" \
                --mode 'incremental')

            echo "Deployment end" | adddate

        fi

    done
}

deployToAWS() {

    echo "Deploying to AWS" | adddate

    # Deploying resources
    echo $APP_CONFIG | jq -c '.resources[]? | select(.deploy)' | while read RESOURCE; do

        COMMENT=$(echo "$RESOURCE" | jq -r .comment)
        TEMPLATE=$(echo "$RESOURCE" | jq -r .templateFileAWS)
        PARAMETERS=$(echo "$RESOURCE" | jq -r .parametersFileAWS)
        CUSTOMDATA=$(echo "$RESOURCE" | jq -r .customDataFile)

        echo "Deploying ${COMMENT}" | adddate

        # If custom data is used
        if [ "$CUSTOMDATA" != null ]
        then
            echo "Deploying with CustomData" | adddate

            # Read and base64 encode custom data (Cloud-Config)
            CUSTOM_DATA="$(cat ${CUSTOMDATA} | openssl enc -base64 | sed ':a;N;$!ba;s/\n//g')"

            echo "Using template: ${TEMPLATE}" | adddate
            echo "Using parameter file: ${PARAMETERS}" | adddate

            # Read parameters file, inject custom data and save to temp file
            PARAM_DATA=$(sed -e "s|<USERDATA>|${CUSTOM_DATA}|" $PARAMETERS)
            echo "$PARAM_DATA" > ./paramFile.json

            # Deploy stack
            AWS_DEPLOY=$(aws cloudformation create-stack \
                --stack-name 'GitLab' \
                --template-body file://${TEMPLATE} \
                --parameters file://./paramFile.json)

            echo "Deployed AWS stack" | adddate

            # Remove temp parameters file
            rm ./paramFile.json

        else
            echo "Using template: ${TEMPLATE}" | adddate
            echo "Using parameter file: ${PARAMETERS}" | adddate

            AWS_DEPLOY=$(aws cloudformation create-stack \
                --stack-name 'GitLab' \
                --template-body file://${TEMPLATE} \
                --parameters file://${PARAMETERS})

            echo "Deployed AWS stack" | adddate

        fi

        # Wait until stack deployment is complete
        echo "Waiting until stack deployment is complete" | adddate
        aws cloudformation wait stack-create-complete \
            --stack-name 'GitLab'

    done
}

updateAzureDNS() {

    # Get public ip AWS
    AWS_PUBLIC_IP=$(aws ec2 describe-instances --filters "Name=tag:aws:cloudformation:stack-name,Values=GitLab" --query "Reservations[*].Instances[*].PublicIpAddress" --output=text)
    echo "AWS Public IP: ${AWS_PUBLIC_IP}" | adddate

    # Get public IP Azure
    AZURE_PUBLIC_IP=$(az vm list -g Demo-ReleasePipeline -d --query [*].[publicIps] | jq -r .[0][0])
    echo "Azure Public IP: ${AZURE_PUBLIC_IP}" | adddate

    # Get current DNS values
    CURRENT_DNS_GITLAB=$(az network dns record-set a show -n gitlab -g psconfeu2017demo -z demo.powershell.no --query "arecords[*].ipv4Address" -o tsv)
    CURRENT_DNS_AZURE=$(az network dns record-set a show -n azure-gitlab -g psconfeu2017demo -z demo.powershell.no --query "arecords[*].ipv4Address" -o tsv)
    CURRENT_DNS_AWS=$(az network dns record-set a show -n aws-gitlab -g psconfeu2017demo -z demo.powershell.no --query "arecords[*].ipv4Address" -o tsv)

    # Update aws-gitlab record if needed
    if [ "$AWS_PUBLIC_IP" != "$CURRENT_DNS_AWS" ]
    then
        AZ_DNS_DEL=$(az network dns record-set a delete -n 'aws-gitlab' -g 'psconfeu2017demo' -z 'demo.powershell.no' -y)
        echo "Removed old record from AzureDNS (aws-gitlab)" | adddate

        AZ_DNS_SET=$(az network dns record-set a create -n aws-gitlab -g psconfeu2017demo -z demo.powershell.no --ttl 60)
        AZ_DNS_RECORD=$(az network dns record-set a add-record -n aws-gitlab -g psconfeu2017demo -z demo.powershell.no -a ${AWS_PUBLIC_IP})
        echo "Added new record in AzureDNS (aws-gitlab)" | adddate
    else
        echo "AzureDNS record 'aws-gitlab' already correct - nothing to do"
    fi

    # Update azure-gitlab record if needed
    if [ "$AZURE_PUBLIC_IP" != "$CURRENT_DNS_AZURE" ]
    then
        AZ_DNS_DEL=$(az network dns record-set a delete -n 'azure-gitlab' -g 'psconfeu2017demo' -z 'demo.powershell.no' -y)
        echo "Removed old record from AzureDNS (azure-gitlab)" | adddate

        AZ_DNS_SET=$(az network dns record-set a create -n azure-gitlab -g psconfeu2017demo -z demo.powershell.no --ttl 60)
        AZ_DNS_RECORD=$(az network dns record-set a add-record -n azure-gitlab -g psconfeu2017demo -z demo.powershell.no -a ${AZURE_PUBLIC_IP})
        echo "Added new record-set in AzureDNS (azure-gitlab)" | adddate
    else
        echo "AzureDNS record 'azure-gitlab' already correct - nothing to do"
    fi

    # Update gitlab record if needed
    case "$CLOUD" in
        Azure)

            if [ "$CURRENT_DNS_GITLAB" != "$AZURE_PUBLIC_IP" ]
            then
                AZ_DNS_DEL=$(az network dns record-set a delete -n 'gitlab' -g 'psconfeu2017demo' -z 'demo.powershell.no' -y)
                echo "Removed old record from AzureDNS (gitlab)" | adddate

                AZ_DNS_SET=$(az network dns record-set a create -n gitlab -g psconfeu2017demo -z demo.powershell.no --ttl 60)
                AZ_DNS_RECORD=$(az network dns record-set a add-record -n gitlab -g psconfeu2017demo -z demo.powershell.no -a ${AZURE_PUBLIC_IP})
                echo "Added new record-set in AzureDNS (gitlab > Azure)" | adddate
            else
                echo "AzureDNS record 'gitlab' already correct - nothing to do (gitlab > Azure)"
            fi
            ;;
        AWS)

            if [ "$CURRENT_DNS_GITLAB" != "$AWS_PUBLIC_IP" ]
            then
                AZ_DNS_DEL=$(az network dns record-set a delete -n 'gitlab' -g 'psconfeu2017demo' -z 'demo.powershell.no' -y)
                echo "Removed old record from AzureDNS (gitlab)" | adddate

                AZ_DNS_SET=$(az network dns record-set a create -n gitlab -g psconfeu2017demo -z demo.powershell.no --ttl 60)
                AZ_DNS_RECORD=$(az network dns record-set a add-record -n gitlab -g psconfeu2017demo -z demo.powershell.no -a ${AWS_PUBLIC_IP})
                echo "Added new record-set in AzureDNS (gitlab > AWS)" | adddate
            else
                echo "AzureDNS record 'gitlab' already correct - nothing to do (gitlab > AWS)"
            fi
            ;;
    esac
}

awsStartIfStopped() {
    # When trying to deploy an already deployed AWS stack, the operation will fail without
    # doing anything. In case the stack have been deployed, but the instance is powered off,
    # we need to power it on now since AWS will be the active cloud
    AWS_INSTANCE=$(aws ec2 describe-instances --filters Name=tag:aws:cloudformation:stack-name,Values=GitLab --query "Reservations[*].Instances[*].[InstanceId, State.Name]" --output=text)
    AWS_INSTANCE_STATE=$(echo "$AWS_INSTANCE" | awk '{print $2}')
    AWS_INSTANCE_ID=$(echo "$AWS_INSTANCE" | awk '{print $1}')
    # Only start if instance is previously stopped
    if [ "$AWS_INSTANCE_STATE" == "stopped" ]
    then
        echo "AWS instance already deployed, but in a stopped state" | adddate
        AWS_START=$(aws ec2 start-instances --instance-ids ${AWS_INSTANCE_ID})
        echo "Instance started" | adddate
    fi
}

enableOrDisableWebtests() {
    if [ "$AUTO_FAILOVER"  == "true" ]
    then
        AZ_RESOURCE=$(az resource update --resource-type microsoft.insights/webtests --name  'http test - gitlab-psconfeu-gitlab' --resource-group PSConfEU-GitLab-AppInsights --set properties.Enabled=true)
        echo "Enabled webtests" | adddate
    else
        AZ_RESOURCE=$(az resource update --resource-type microsoft.insights/webtests --name  'http test - gitlab-psconfeu-gitlab' --resource-group PSConfEU-GitLab-AppInsights --set properties.Enabled=false)
        echo "Disabled webtests" | adddate
    fi
}
