#!/bin/bash

SECONDS=0

# Read helper functions
source ./scripts/functions.sh

# Save arguments
AZURE_USER=$1
AZURE_PW=$2
AZURE_TENANT=$3
AWS_USER=$4
AWS_PW=$5

# Read config
APP_CONFIG=$(cat ./app.config.json)
MODE=$(echo "$APP_CONFIG" | jq .Mode -r)
CLOUD=$(echo "$APP_CONFIG" | jq .ActiveCloud -r)
AZURE_LOCATION=$(echo "$APP_CONFIG" | jq .AzureLocation -r)
AWS_LOCATION=$(echo "$APP_CONFIG" | jq .AWSLocation -r)
AZURE_RESOURCE_GROUP=$(echo "$APP_CONFIG" | jq .AzureResourceGroup -r)
AUTO_FAILOVER=$(echo "$APP_CONFIG" | jq .AutomaticFailover -r)
BUILD=$(echo "$APP_CONFIG" | jq .AutomaticBuilds -r)

# Set up authentication to Azure
AZ_LOGIN=$(az login --username $AZURE_USER --password $AZURE_PW --tenant $AZURE_TENANT --service-principal)
echo "Authenticated to Azure" | adddate

# If automatic build is set to false, exit now
if [ "$BUILD"  == "false" ]
then
    echo "Skipping automatic build" | adddate
    enableOrDisableWebtests
    exit 0
fi

# Set up environment for AWS
aws configure set aws_access_key_id $AWS_USER
aws configure set aws_secret_access_key $AWS_PW
aws configure set default.region $AWS_LOCATION
echo "Environment set up for AWS" | adddate

# Choose correct deployment method based on mode setting
if [ "$MODE" == 'SingleCloud' ]; then
    echo "Mode: $MODE"

    case "$CLOUD" in
        Azure)

            deployToAzure

            updateAzureDNS

            # Delete the AWS stack
            aws cloudformation delete-stack --stack-name 'GitLab'
            echo "Deleted AWS stack" | adddate
            ;;

        AWS)

            deployToAWS

            awsStartIfStopped

            updateAzureDNS

            # Remove resources in Azure
            AZ_DELETE=$(az group delete -n ${AZURE_RESOURCE_GROUP} --no-wait -y)
            echo "Deleting Azure Resource Group" | adddate

            ;;

    esac

elif [ "$MODE" == 'ActivePassive' ]; then
    echo "Mode: $MODE"

    deployToAzure
    deployToAWS

    # After deployment all resources will be active
    # But since we are deploying in an Active/Passive mode
    # we need to shutdown the passive server
    case "$CLOUD" in
        Azure)
            # Azure is the active cloud
            # Get the instance ID of the AWS ec2 instance
            AWS_INSTANCE_ID=$(aws ec2 describe-instances --filters Name=tag:aws:cloudformation:stack-name,Values=GitLab --query "Reservations[*].Instances[*].[InstanceId, State.Name]" --output=text | grep -E "running|pending" | awk '{print $1}')
            # Since we have just deployed we have to wait until it's running before we can stop it
            aws ec2 wait instance-running --instance-ids ${AWS_INSTANCE_ID}
            AWS_STOP=$(aws ec2 stop-instances --instance-ids ${AWS_INSTANCE_ID})
            ;;
        AWS)
            # AWS is the active cloud
            # Stop all machines in the Azure resource group
            AZ_STOP=$(az vm stop --ids $(az vm list -g Demo-ReleasePipeline --query "[].id"  -o tsv) --no-wait)

            awsStartIfStopped
            ;;
    esac

    # The last thing to do is to update DNS
    updateAzureDNS

elif [ "$MODE" == 'ActiveActive' ]; then
    echo "Mode: $MODE"

    deployToAzure
    deployToAWS

    awsStartIfStopped

    # The last thing to do is to update DNS
    updateAzureDNS

fi

# Enable or Disable web tests based on settings in the config file
enableOrDisableWebtests

printf "Done ($(convertsecs $SECONDS))\n"