[CmdletBinding()]
<#
    .SYNOPSIS
        Start script in Docker container
    .DESCRIPTION
        Start script in Docker container
#>
param (
    # Name of script to run
    [Parameter(Mandatory, Position = 0)]
    [string] $Script,

    # Azure Service Principal username
    [Parameter(Mandatory, Position = 1)]
    [string] $AzureUsername,

    # Azure Service Principal password
    [Parameter(Mandatory, Position = 2)]
    [string] $AzurePassword,

    # Azure tenant ID
    [Parameter(Mandatory, Position = 3)]
    [string] $AzureTenant,

    # AWS Access Key ID
    [Parameter(Mandatory, Position = 4)]
    [Alias('AwsUsername')]
    [string] $AwsAccessKeyId,

    # AWS Secret Access Key
    [Parameter(Mandatory, Position = 5)]
    [Alias('AwsPassword')]
    [string] $AwsSecretAccessKey
)

# Verify that script exists
if (-not (Test-Path -Path "./scripts/$($Script).sh")) {
    Write-Warning "./scripts/$($Script).sh not found!"
    break
}

# Verify that Docker image exists
$imageId = docker images cloudcli -q
if (-not $imageId) {
    Write-Warning "Docker image 'cloudcli' not found!"
    Write-Warning "Please run 'docker build -t ""cloudcli:dockerfile"" -f .\docker\Dockerfile .'"
    break
}

# Run script in Docker
try {
    docker run --rm -it -v "$($PWD):/local" -w /local cloudcli:dockerfile /bin/bash -c "./scripts/$($Script).sh $($AzureUsername) $($AzurePassword) $($AzureTenant) $($AwsAccessKeyId) $($AwsSecretAccessKey)"
}

catch {
    Write-Warning $_.Exception.Message
}

#docker run --rm -it -v "$($PWD):/local" -w /local cloudcli:dockerfile /bin/bash -c "./scripts/$($args[0]).sh $($args[1]) $($args[2]) $($args[3]) $($args[4]) $($args[5])"