#!/bin/bash

if [ -e "./app.config.json" ]
then
    TESTS_FAILED=false
    COUNTER=0
    echo "app.config.json exists"

    CFG=$(cat ./app.config.json)

    # DeploymentName
    TEST_VAL=$(echo "$CFG" | jq -r .DeploymentName)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "DeploymentName: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # DNSName
    TEST_VAL=$(echo "$CFG" | jq -r .DNSName)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "DNSName: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # AzureResourceGroup
    TEST_VAL=$(echo "$CFG" | jq -r .AzureResourceGroup)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "AzureResourceGroup: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # AzureLocation
    TEST_VAL=$(echo "$CFG" | jq -r .AzureLocation)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "AzureLocation: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # AzureDNSName
    TEST_VAL=$(echo "$CFG" | jq -r .AzureDNSName)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "AzureDNSName: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # AWSLocation
    TEST_VAL=$(echo "$CFG" | jq -r .AWSLocation)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "AWSLocation: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # AWSDNSName
    TEST_VAL=$(echo "$CFG" | jq -r .AWSDNSName)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "AWSDNSName: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # Mode
    TEST_VAL=$(echo "$CFG" | jq -r .Mode)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "Mode: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    elif [[ "$TEST_VAL" != "SingleCloud" ]] && [[ "$TEST_VAL" != "ActivePassive" ]] && [[ "$TEST_VAL" != "ActiveActive" ]]
    then
        echo "Mode: incorrect value [$TEST_VAL]! (Should be 'SingleCloud', 'ActivePassive' or 'ActiveActive'"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # ActiveCloud
    TEST_VAL=$(echo "$CFG" | jq -r .ActiveCloud)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "ActiveCloud: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # AutomaticFailover
    TEST_VAL=$(echo "$CFG" | jq -r .AutomaticFailover)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "AutomaticFailover: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    elif [[ "$TEST_VAL" != "true" ]] && [[ "$TEST_VAL" != "false" ]]
    then
        echo "AutomaticFailover: incorrect value [$TEST_VAL]! (Should be 'true' or 'false'"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # AutomaticBuilds
    TEST_VAL=$(echo "$CFG" | jq -r .AutomaticBuilds)
    if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
    then
        echo "AutomaticBuilds: missing value!"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    elif [[ "$TEST_VAL" != "true" ]] && [[ "$TEST_VAL" != "false" ]]
    then
        echo "AutomaticBuilds: incorrect value [$TEST_VAL]! (Should be 'true' or 'false'"
        TESTS_FAILED=true
        COUNTER=$[COUNTER + 1]
    fi

    # Resources
    echo $CFG | jq -c '.resources[]? | select(.deploy)' | while read RESOURCE; do

        # deploy
        TEST_VAL=$(echo "$RESOURCE" | jq -r .deploy)
            if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
            then
                echo "deploy: missing value!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            elif [[ "$TEST_VAL" != "true" ]] && [[ "$TEST_VAL" != "false" ]]
            then
                echo "deploy: incorrect value [$TEST_VAL]! (Should be 'true' or 'false'"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            fi

        # templateFileAzure
        TEST_VAL=$(echo "$RESOURCE" | jq -r .templateFileAzure)
            if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
            then
                echo "templateFileAzure: missing value!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            elif [[ ! -f "$TEST_VAL" ]]
            then
                echo "templateFileAzure: file not found! [$TEST_VAL]!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            fi

        # templateFileAWS
        TEST_VAL=$(echo "$RESOURCE" | jq -r .templateFileAWS)
            if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
            then
                echo "templateFileAWS: missing value!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            elif [[ ! -f "$TEST_VAL" ]]
            then
                echo "templateFileAWS: file not found! [$TEST_VAL]!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            fi

        # parametersFileAzure
        TEST_VAL=$(echo "$RESOURCE" | jq -r .parametersFileAzure)
            if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
            then
                echo "parametersFileAzure: missing value!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            elif [[ ! -f "$TEST_VAL" ]]
            then
                echo "parametersFileAzure: file not found! [$TEST_VAL]!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            fi

        # parametersFileAWS
        TEST_VAL=$(echo "$RESOURCE" | jq -r .parametersFileAWS)
            if [[ -z ${TEST_VAL// } ]] || [[ "$TEST_VAL" == "null" ]]
            then
                echo "parametersFileAWS: missing value!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            elif [[ ! -f "$TEST_VAL" ]]
            then
                echo "parametersFileAWS: file not found! [$TEST_VAL]!"
                TESTS_FAILED=true
                COUNTER=$[COUNTER + 1]
            fi

    done

    if [[ "$TESTS_FAILED" == true ]]
    then
        echo "$COUNTER Test(s) failed!"
        exit 1
    else
        echo "All tests passed!"
    fi

else
    echo "app.config.json not found"
    exit 1
fi