param (
    [object]$WebHookData
    )

#region Process input

if ($WebhookData) 
{

# Debugging (export input data to disk on Hybrid Worker for manual inspection/testing)
# $WebHookData | Export-CliXml C:\temp\webhookdata.xml

  Write-Output -InputObject 'Getting parameter values from WebhookData'

  $WebhookName    = $WebhookData.WebhookName
  $WebhookHeaders = $WebhookData.RequestHeader
  $WebhookBody    = $WebhookData.RequestBody | ConvertFrom-Json

  $AlertContext   = $WebhookBody.context
  $AlertStatus    = $WebhookBody.status

}
else 
{
  Write-Output -InputObject 'No input from webhook, aborting...'
  break
}

#endregion

#region Prerequisites

try 
{
        Import-Module -Name AzureRm.Dns -ErrorAction Stop -MinimumVersion 2.7.0
        Import-Module -Name GitLib2 -ErrorAction Stop
        Import-Module -Name Orchestrator.AssetManagement.Cmdlets -ErrorAction Stop # Module auto-loading will import the wrong module when AzureAutomationAuthoringToolkit is installed on hybrid runbook worker, thus we need to explicitly import the correct module
}
catch 
{
        throw 'Prerequisites not installed (AzureRm.Dns, GitLib2 or Orchestrator.AssetManagement.Cmdlets PowerShell module(s) not installed'
}

#endregion

#region Variables

try {

    $AzureCredential =  Get-AutomationPSCredential -Name cred-Azure -ErrorAction Stop
    $GitCredential =  Get-AutomationPSCredential -Name cred-GitHub -ErrorAction Stop
    $GitRepositoryUrl =   Get-AutomationVariable -Name GitRepositoryUrl -ErrorAction Stop

}

catch {
    
    throw 'Failed to retrieve required assets from Azure Automation, aborting...'

}

$TempFolder = Join-Path -Path $env:temp -ChildPath ((New-TemporaryFile).Name -replace '.tmp','')
Copy-GitRepository -Source $GitRepositoryUrl -DestinationPath $TempFolder -Credential $GitCredential

cd $TempFolder

$Configuration = Get-Content -Path .\app.config.json -Raw | ConvertFrom-Json

$AzureDNSZoneResourceGroupName = $Configuration.resources[1].AzureResourceGroupName
$GitLabDNSName = $Configuration.DNSName
$DNSZoneName =  $Configuration.resources[1].AzureDNSZoneName
$GitLabAzureDNSName = $Configuration.AzureDNSName
$GitLabAWSDNSName =  $Configuration.AWSDNSName

#endregion

switch ($AlertStatus) {

    'Activated' {
        $AlertActivated = $true
        Write-Output 'Alert was raised in Application Inisights, taking action...'
    }

    'Resolved' {Write-Output 'Alert was resolved in Application Inisights, no action taken...'}

    default {Write-Output "Unknown alert status ($($AlertStatus)), aborting"}

}

if ($AlertActivated) {

    Write-Output "Processing activated alert with context:"
    $AlertContext


try {

    $CurrentIPAddress = (Resolve-DnsName -Name $GitLabDNSName -Type A -ErrorAction Stop).IPAddress
    $CurrentGitLabAzureIPAddress = (Resolve-DnsName -Name $GitLabAzureDNSName -Type A -ErrorAction Stop).IPAddress
    $CurrentGitLabAWSIPAddress = (Resolve-DnsName -Name $GitLabAWSDNSName -Type A -ErrorAction Stop).IPAddress

}

catch {

    Write-Output 'Failed to resolve all of the required DNS records, aborting...'
    Write-Output 'Error message:'
    $_.Exception.Message

    break

}

switch ($CurrentIPAddress) {

    $CurrentGitLabAWSIPAddress {

       Write-Output 'Deployment is currently running on AWS'
       $CurrentCloudEnvironment = 'AWS'

    }

    $CurrentGitLabAzureIPAddress {

        Write-Output 'Deployment is currently running on Azure'
        $CurrentCloudEnvironment = 'Azure'

    }

    default {

        Write-Output "Deployment is currently running on an unknown IP Address, no action taken..."
        $CurrentCloudEnvironment = 'Unknown'

        exit

    }

}

try {

$null = Add-AzureRmAccount -Credential $AzureCredential -ErrorAction Stop
$null = Select-AzureRmSubscription -SubscriptionId b7f543e7-29f0-4e13-8b16-e8e94170be88 -ErrorAction Stop

switch ($CurrentCloudEnvironment) {

'AWS' {

    Write-Output "Replacing current DNS record value $($CurrentIPAddress) in external DNS zone with Azure cloud deployment IP address $CurrentGitLabAzureIPAddress"

    Get-AzureRmDnsRecordSet -Name ($GitLabDNSName -split '\.')[0] -RecordType A -ZoneName $DNSZoneName -ResourceGroupName $ResourceGroupName | Remove-AzureRmDnsRecordSet -Confirm:$false -ErrorAction Ignore
    New-AzureRmDnsRecordSet -Name ($GitLabDNSName -split '\.')[0] -RecordType A -ZoneName $DNSZoneName -ResourceGroupName $ResourceGroupName -Ttl 1 -DnsRecords (New-AzureRmDnsRecordConfig -IPv4Address $CurrentGitLabAzureIPAddress) -ErrorAction Stop

    Write-Output 'Cloud deployment`s external IP address is switched from AWS to Azure'

}
'Azure' {

    Write-Output "Replacing current DNS record value $($CurrentIPAddress) in external DNS zone with AWS cloud deployment IP address $CurrentGitLabAWSIPAddress"

    Get-AzureRmDnsRecordSet -Name ($GitLabDNSName -split '\.')[0] -RecordType A -ZoneName $DNSZoneName -ResourceGroupName $ResourceGroupName | Remove-AzureRmDnsRecordSet -Confirm:$false -ErrorAction Ignore
    New-AzureRmDnsRecordSet -Name ($GitLabDNSName -split '\.')[0] -RecordType A -ZoneName $DNSZoneName -ResourceGroupName $ResourceGroupName -Ttl 1 -DnsRecords (New-AzureRmDnsRecordConfig -IPv4Address $CurrentGitLabAWSIPAddress) -ErrorAction Stop

    Write-Output 'Cloud deployment`s external IP address is switched from Azure to AWS'

}

}

}

catch {

    throw "An error occured when trying to switch cloud deployment`s external IP address; $($_.Exception.Message)"

}

}

#region Cleanup

cd $env:temp
$null = Remove-Item -Path $TempFolder -Force -Recurse -ErrorAction Ignore

#endregion

Write-Output 'Runbook ended'