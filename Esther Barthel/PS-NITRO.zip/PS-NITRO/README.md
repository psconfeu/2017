# PS-NITRO
PowerShell Module for NITRO (REST API) communication with Citrix NetScaler (Automation DevOps)

I have uploaded the latest version of my PowerShell Module code and the sample scripts used in the presentations at the PowerShell Conference EU 2017 in Hannover.

As I am still learning how to work with GitHub and PowerShell every day I'm still determining the best way to share my module and demo scripts with you all, so please be patient or give me some feedback/tips/tricks/advice on how to improve my code and repository.

Haveave fun with the code!

Cheers,
Esther
