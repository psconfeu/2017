Write-Host "this is my evil script"

