﻿#Import von Modulen
Import-Module ServerManager

#Variablen

$servers = ('HVV01','HVV02')


#Installieren von Features
#Install-WindowsFeature -Name Hyper-v -IncludeAllSubFeature -IncludeManagementTools -Restart
foreach($server in $servers){
    Install-WindowsFeature -Name Failover-Clustering -IncludeAllSubFeature -IncludeManagementTools -ComputerName $server
    Install-WindowsFeature -Name Hyper-v -IncludeAllSubFeature -IncludeManagementTools -Restart
}

#Cluster Test
Test-Cluster -Node HVV01,HVV02

#Erstellen neuer Cluster
New-Cluster -Name CLUSTERV01 -Node HVV01,HVV02 -StaticAddress 192.168.1.67

#Anzeigen Verfuegbarer Speicher
Get-ClusterAvailableDisk -Cluster CLUSTERV01

#Alle Verfuegbaren Cluster Disks hinzufügen
Get-ClusterAvailableDisk -Cluster CLUSTERV01 | Add-ClusterDisk

#Verbindung auf SCVMM Server
Enter-PSSession -ComputerName VMM01

#Deaktivieren Autoerstellung Netwerke
Set-SCVMMServer -AutomaticLogicalNetworkCreationEnabled $false -LogicalNetworkMatch "Disabled" -BackupLogicalNetworkMatch "Disabled"

#Add RunAs Account
$credential = Get-Credential
$runAsAccount = New-SCRunAsAccount -Credential $credential -Name "VMMHostAccess02"


#Erteilen Berechtigungen
Exit-PSSession
Enter-PSSession CLUSTERV01.legendary.local
Grant-ClusterAccess -Cluster CLUSTERV01.legendary.local -User "legendary.local\Administrator" -Full
Exit-PSSession

#Hinzufügen eines Clusters
Enter-PSSession VMM01.legendary.local
$Credential = Get-SCRunAsAccount -Name "VMMHostAccess02"
$VMHostGroup = Get-SCVMHostGroup | where {$_.Path -eq "All Hosts"}
Add-SCVMHostCluster -Name "CLUSTERV01.legendary.local" -VMHostGroup $VMHostGroup -RemoteConnectEnabled $True -RemoteConnectPort 5900 -Credential $Credential

#Define Contraint Delegation on FileServers (SMB3)
Install-WindowsFeature RSAT-AD-PowerShell

Enable-SmbDelegation –SmbServer FS01.legendary.local –SmbClient HyperV01
Enable-SmbDelegation –SmbServer FS02.legendary.local –SmbClient HyperV01
Enable-SmbDelegation –SmbServer FS01.legendary.local –SmbClient HyperV02
Enable-SmbDelegation –SmbServer FS02.legendary.local –SmbClient HyperV02

#Create  New Locial Network
$logicalNetwork = New-SCLogicalNetwork -Name "LN_LabNet01" -LogicalNetworkDefinitionIsolation $false -EnableNetworkVirtualization $false -UseGRE $false -IsPVLAN $false
$myTempHostID = Get-SCVMHostGroup | where {$_.Path -eq "All Hosts"}
$allHostGroups = @()
$allHostGroups += Get-SCVMHostGroup -ID $myTempHostID.ID
$allSubnetVlan = @()
$allSubnetVlan += New-SCSubnetVLan -Subnet "192.168.1.1/24" -VLanID 0

New-SCLogicalNetworkDefinition -Name "MainSite" -LogicalNetwork $logicalNetwork -VMHostGroup $allHostGroups -SubnetVLan $allSubnetVlan -RunAsynchronously

$logicalNetwork = New-SCLogicalNetwork -Name "LN_LabNet02" -LogicalNetworkDefinitionIsolation $false -EnableNetworkVirtualization $false -UseGRE $false -IsPVLAN $false
$myTempHostID = Get-SCVMHostGroup | where {$_.Path -eq "All Hosts"}
$allHostGroups = @()
$allHostGroups += Get-SCVMHostGroup -ID $myTempHostID.ID
$allSubnetVlan = @()
$allSubnetVlan += New-SCSubnetVLan -VLanID 0


New-SCLogicalNetworkDefinition -Name "SecondarySite" -LogicalNetwork $logicalNetwork -VMHostGroup $allHostGroups -SubnetVLan $allSubnetVlan -RunAsynchronously

#Hinzufügen eines Port Uplink Profiles
$definition = @()
$definition += Get-SCLogicalNetworkDefinition -Name "MainSite" 
New-SCNativeUplinkPortProfile -Name "Lab01_Uplink" -Description "" -LogicalNetworkDefinition $definition -EnableNetworkVirtualization $false -LBFOLoadBalancingAlgorithm "Dynamic" -LBFOTeamMode "SwitchIndependent" -RunAsynchronously

#Erstellen eines Loigical Switch


$virtualSwitchExtensions = @()
$virtualSwitchExtensions += Get-SCVirtualSwitchExtension -Name "Microsoft Windows Filtering Platform"
$logicalSwitch = New-SCLogicalSwitch -Name "MyLogicalSwitch01" -Description "" -EnableSriov $false -SwitchUplinkMode "Team" -VirtualSwitchExtensions $virtualSwitchExtensions

$nativeProfile = Get-SCNativeUplinkPortProfile -Name "Lab01_Uplink" 
New-SCUplinkPortProfileSet -Name "Lab01_Uplink_3ffac465-e740-43c8-b333-75957d8b5ebd" -LogicalSwitch $logicalSwitch -RunAsynchronously -NativeUplinkPortProfile $nativeProfile


#Setzen des Logical Switches auf den Hyper-V Nodes
$vmHosts = "HVV01","HVV02"
foreach ($vmHost in $vmHosts) {


$guid = [guid]::NewGuid()
$vmHost = Get-SCVMHost -ComputerName $vmHost
$networkAdapter = Get-SCVMHostNetworkAdapter -Name "Microsoft Hyper-V Network Adapter" -VMHost $vmHost
$uplinkPortProfileSet = Get-SCUplinkPortProfileSet -Name "Lab01_Uplink_3ffac465-e740-43c8-b333-75957d8b5ebd"
Set-SCVMHostNetworkAdapter -VMHostNetworkAdapter $networkAdapter -UplinkPortProfileSet $uplinkPortProfileSet -UsedForManagement $true -JobGroup $guid
$networkAdapter = Get-SCVMHostNetworkAdapter -Name "Microsoft Hyper-V Network Adapter" -VMHost $vmHost
$logicalSwitch = Get-SCLogicalSwitch -Name "MyLogicalSwitch01"
$vmNetwork = Get-SCVMNetwork -Name "VN_LabNet01"
New-SCVirtualNetwork -VMHost $vmHost -VMHostNetworkAdapters $networkAdapter -LogicalSwitch $logicalSwitch -JobGroup $guid -CreateManagementAdapter -ManagementAdapterName "MGMT" -ManagementAdapterVMNetwork $vmNetwork

#New-SCVirtualNetwork -VMHost $vmHost -VMHostNetworkAdapters $networkAdapter -LogicalSwitch $logicalSwitch -JobGroup $guid


Set-SCVMHost -VMHost $vmHost -JobGroup $guid -RunAsynchronously
}
 
#Erstellen VM Network auf Logical-Switch

$logicalNetwork = Get-SCLogicalNetwork -Name "LN_LabNet01" 
$vmNetwork = New-SCVMNetwork -Name "VN_LabNet01" -LogicalNetwork $logicalNetwork -IsolationType "NoIsolation"
Write-Output $vmNetwork

#Hinzufügen IP Pool Logical Network
$logicalNetwork = Get-SCLogicalNetwork -Name "LN_LabNet01" 
$logicalNetworkDefinition = Get-SCLogicalNetworkDefinition -LogicalNetwork $logicalNetwork -Name "MainSite"
# Gateways
$allGateways = @()
# DNS servers 
$allDnsServer = @()
# DNS suffixes
$allDnsSuffixes = @()
# WINS servers
$allWinsServers = @()
New-SCStaticIPAddressPool -Name "CloudIPPool" -LogicalNetworkDefinition $logicalNetworkDefinition -Subnet "192.168.1.1/24" -IPAddressRangeStart "192.168.1.50" -IPAddressRangeEnd "192.168.1.200" -DefaultGateway $allGateways -DNSServer $allDnsServer -DNSSuffix "" -DNSSearchSuffix $allDnsSuffixes -RunAsynchronously

#Hinzufügen Storage Klassifikation
New-SCStorageClassification -Name "Gold" -Description ""

#Hinzufügen eines Storage Providers
$runAsAccount = Get-SCRunAsAccount -Name "VMMHostAccess02"
Add-SCStorageProvider -ComputerName "VMM01.legendary.local" -AddWindowsNativeWmiProvider -Name "VMM01.legendary.local" -RunAsAccount $runAsAccount -RunAsynchronously

#Erstellen eines Shares
$storageFileServer = Get-SCStorageFileServer -Name "VMM01.legendary.local"
$storageClassification = Get-SCStorageClassification -Name "Gold"
$storageFileShare = New-SCStorageFileShare -StorageFileServer $storageFileServer -Name "VMS01" -Description "" -LocalPath "D:\VMS01" -RunAsynchronously -StorageClassification $storageClassification

#Zuweisen des Shares auf die HostGroup
$guid = [guid]::NewGuid()
$hostCluster = Get-SCVMHostCluster -Name "CLUSTERV01.legendary.local"

$addedShare = Get-SCStorageFileShare -Name "VMS01"
Register-SCStorageFileShare -StorageFileShare $addedShare -VMHostCluster $hostCluster -JobGroup $guid

$clusterNode = Get-SCVMHost -ComputerName HVV01
Set-SCVMHost -VMHost $clusterNode -BaseDiskPaths "\\VMM01.legendary.local\VMS01" -RunAsynchronously
$clusterNode = Get-SCVMHost -ComputerName HVV02
Set-SCVMHost -VMHost $clusterNode -BaseDiskPaths "\\VMM01.legendary.local\VMS01" -RunAsynchronously

Set-SCVMHostCluster -Description "" -RunAsynchronously -VMHostCluster $hostCluster -JobGroup $guid -ClusterReserve "1"



#Erstellen einer neuen Cloud
$guid = [guid]::NewGuid()
Set-SCCloudCapacity -JobGroup $guid -UseCustomQuotaCountMaximum $true -UseMemoryMBMaximum $true -UseCPUCountMaximum $true -UseStorageGBMaximum $true -UseVMCountMaximum $true

$addCapabilityProfiles = @()
$addCapabilityProfiles += Get-SCCapabilityProfile -Name "Hyper-V"

Set-SCCloud -JobGroup $guid -RunAsynchronously -ReadWriteLibraryPath "\\VMM01.legendary.local\MSSCVMMLibrary\VHDs" -AddCapabilityProfile $addCapabilityProfiles
$myTempHostID = Get-SCVMHostGroup | where {$_.Path -eq "All Hosts"}

$hostGroups = @()
$hostGroups += Get-SCVMHostGroup -ID $myTempHostID.ID
New-SCCloud -JobGroup $guid -VMHostGroup $hostGroups -Name "MyCloud01" -Description "" -RunAsynchronously


#Erstellen eines neuen Tenant
$guid = [guid]::NewGuid()
$scopeToAdd = @()
$scopeToAdd += Get-SCCloud  -Name "MyCloud01"
$cloudsToAdd_0 = Get-SCCloud -Name "MyCloud01"
Add-SCUserRolePermission -Cloud $cloudsToAdd_0 -JobGroup $guid -CheckpointRestoreOnly -DeployFromTemplateOnly
Set-SCUserRole -JobGroup $guid -AddMember @("Legendary.local\kunde01") -AddScope $scopeToAdd -Permission @() -ShowPROTips $false -VMNetworkMaximumPerUser "0" -VMNetworkMaximum "0"

$cloud = Get-SCCloud -Name "MyCloud01"
Set-SCUserRoleQuota -Cloud $cloud -JobGroup $guid -UseCPUCountMaximum -UseMemoryMBMaximum -UseStorageGBMaximum -UseCustomQuotaCountMaximum -UseVMCountMaximum
Set-SCUserRoleQuota -Cloud $cloud -JobGroup $guid -QuotaPerUser -UseCPUCountMaximum -UseMemoryMBMaximum -UseStorageGBMaximum -UseCustomQuotaCountMaximum -UseVMCountMaximum

$libResource = Get-SCRunAsAccount -Name "VMMHostAccess02" 
Grant-SCResource -Resource $libResource -JobGroup $guid

$libResource = Get-SCVMNetwork -Name "VN_LabNet01"
Grant-SCResource -Resource $libResource -JobGroup $guid

New-SCUserRole -Name "myCloudTenant01" -UserRoleProfile "TenantAdmin" -Description "" -JobGroup $guid



#Erstellen einer neuen VM in der Cloud
$guid = [guid]::NewGuid()
New-SCVirtualScsiAdapter -VMMServer localhost -JobGroup $guid -AdapterID 7 -ShareVirtualScsiAdapter $false -ScsiControllerType DefaultTypeNoType 
New-SCVirtualDVDDrive -VMMServer localhost -JobGroup $guid -Bus 1 -LUN 0 
New-SCVirtualNetworkAdapter -VMMServer localhost -JobGroup $guid -MACAddressType Dynamic -Synthetic -IPv4AddressType Dynamic -IPv6AddressType Dynamic 
Set-SCVirtualCOMPort -NoAttach -VMMServer localhost -GuestPort 1 -JobGroup $guid
Set-SCVirtualCOMPort -NoAttach -VMMServer localhost -GuestPort 2 -JobGroup $guid 
Set-SCVirtualFloppyDrive -RunAsynchronously -VMMServer localhost -NoMedia -JobGroup $guid
$CPUType = Get-SCCPUType -VMMServer localhost | where {$_.Name -eq "3.60 GHz Xeon (2 MB L2 cache)"}
$CapabilityProfile = Get-SCCapabilityProfile -VMMServer localhost | where {$_.Name -eq "Hyper-V"}
New-SCHardwareProfile -VMMServer localhost -CPUType $CPUType -Name "Profile01173a87-a260-4ec7-8757-23fc2a64c7bd" -Description "Profile used to create a VM/Template" -CPUCount 2 -MemoryMB 1024 -DynamicMemoryEnabled $false -MemoryWeight 5000 -VirtualVideoAdapterEnabled $false -CPUExpectedUtilizationPercent 20 -DiskIops 0 -CPUMaximumPercent 100 -CPUReserve 0 -NumaIsolationRequired $false -NetworkUtilizationMbps 0 -CPURelativeWeight 100 -HighlyAvailable $true -DRProtectionRequired $false -NumLock $false -BootOrder "CD", "IdeHardDrive", "PxeBoot", "Floppy" -CPULimitFunctionality $false -CPULimitForMigration $false -CapabilityProfile $CapabilityProfile -Generation 1 -JobGroup $guid
New-SCVirtualDiskDrive -VMMServer localhost -IDE -Bus 0 -LUN 0 -JobGroup $guid -VirtualHardDiskSizeMB 40960 -CreateDiffDisk $false -Dynamic -Filename "myTestVM_disk_1" -VolumeType BootAndSystem 
$HardwareProfile = Get-SCHardwareProfile -VMMServer localhost | where {$_.Name -eq "Profile01173a87-a260-4ec7-8757-23fc2a64c7bd"}
New-SCVMTemplate -Name "Temporary Templated0888b36-7a83-4687-b705-46d31f3a5c98" -Generation 1 -HardwareProfile $HardwareProfile -JobGroup $guid -NoCustomization 
$template = Get-SCVMTemplate -All | where { $_.Name -eq "Temporary Templated0888b36-7a83-4687-b705-46d31f3a5c98" }
$virtualMachineConfiguration = New-SCVMConfiguration -VMTemplate $template -Name "myTestVM"
Write-Output $virtualMachineConfiguration
$cloud = Get-SCCloud -Name "MyCloud01"
New-SCVirtualMachine -Name "myTestVM" -VMConfiguration $virtualMachineConfiguration -Cloud $cloud -Description "" -JobGroup $guid -ReturnImmediately -StartAction "NeverAutoTurnOnVM" -StopAction "SaveVM"


$VM = Get-SCVirtualMachine -VMMServer VMM01.legendary.local -Name "myTestVM"
$OperatingSystem = Get-SCOperatingSystem -VMMServer VMM01.legendary.local | where {$_.Name -eq "Windows Server 2012 R2 Standard"}
$UserRole = Get-SCUserRole -VMMServer VMM01.legendary.local  -Name "Administrator"

$CPUType = Get-SCCPUType -VMMServer VMM01.legendary.local | where {$_.Name -eq "3.60 GHz Xeon (2 MB L2 cache)"}

Set-SCVirtualMachine -VM $VM -Name "MyTestVM" -Description "" -OperatingSystem $OperatingSystem -Owner 'legendary\Administrator' -UserRole $UserRole -CPUCount 1 -MemoryMB 512 -DynamicMemoryEnabled $false -MemoryWeight 5000 -VirtualVideoAdapterEnabled $false -CPUExpectedUtilizationPercent 20 -DiskIops 0 -CPUMaximumPercent 100 -CPUReserve 0 -NumaIsolationRequired $false -NetworkUtilizationMbps 0 -CPURelativeWeight 100 -HighlyAvailable $true -HAVMPriority 3000 -DRProtectionRequired $false -NumLock $false -BootOrder "CD", "IdeHardDrive", "PxeBoot", "Floppy" -CPULimitFunctionality $false -CPULimitForMigration $false -CPUType $CPUType -Tag "(none)" -QuotaPoint 1 -JobGroup $guid -RunAsynchronously -DelayStartSeconds 0 -BlockDynamicOptimization $false -EnableOperatingSystemShutdown $true -EnableTimeSynchronization $true -EnableDataExchange $true -EnableHeartbeat $true -EnableBackup $true -RunAsSystem -UseHardwareAssistedVirtualization $true 




<#
#Hinzufuegen FileServer
$runAsAccount = Get-SCRunAsAccount -Name "VMMHostAccess02"
Add-SCStorageProvider -ComputerName "fs01.legendary.local" -AddWindowsNativeWmiProvider -Name "fs01.legendary.local" -RunAsAccount $runAsAccount -RunAsynchronously

#Erstellen FileShare
$storageFileServer = Get-SCStorageFileServer -Name fs01.legendary.local
$storageClassification = Get-SCStorageClassification -Name "Gold"
$storageFileShare = New-SCStorageFileShare -StorageFileServer $storageFileServer -Name "GoldVms" -Description "" -LocalPath "D:\Gold01" -RunAsynchronously -StorageClassification $storageClassification
#>









