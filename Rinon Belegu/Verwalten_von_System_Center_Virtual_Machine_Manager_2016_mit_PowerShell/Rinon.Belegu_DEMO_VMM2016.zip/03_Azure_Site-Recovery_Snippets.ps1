﻿$sid = "AzureID"


Install-Module -Name AzureRM.SiteRecovery
Install-Module -Name AzureRM.RecoveryServices
Install-Module -Name AzureRM.Resources
Install-Module -Name AzureRm.Storage

Install-Module AzureAutomationAuthoringToolkit -Scope CurrentUser
Install-AzureAutomationIseAddOn
Import-Module AzureAutomationAuthoringToolkit
Install-Module -Name ISEScriptAnalyzerAddOn


Login-AzureRmAccount | Out-Null

$SubscriptionName = 'Visual Studio Premium bei MSDN' 
Select-AzureRmSubscription -SubscriptionName $SubscriptionName | Out-Null


Get-Command -Module AzureRM.Resources


Get-AzureRmResourceProvider -ProviderNamespace Microsoft.RecoveryServices
Get-AzureRmResourceProvider -ProviderNamespace Microsoft.SiteRecovery


Register-AzureRmResourceProvider -ProviderNamespace Microsoft.SiteRecovery

Register-AzureRmResourceProvider -ProviderNamespace Microsoft.RecoveryServices


Get-AzureRmResourceProvider -ProviderNamespace Microsoft.RecoveryServices
Get-AzureRmResourceProvider -ProviderNamespace Microsoft.SiteRecovery

$ResourceGroupName  = "PSconf01"
$Geo = "West Europe"

New-AzureRmResourceGroup -Name $ResourceGroupName -Location $Geo  | select ResourceGroupName,Location,ProvisioningState | fl

$vault = New-AzureRmRecoveryServicesVault -Name vaultPsconf01 -ResourceGroupName $ResourceGroupName -Location $Geo | select Name,Type,Location,ResouceGroupName,Properties
$vault | select Name,Type,Location,ResouceGroupName,Properties | fl

Get-AzureRmRecoveryServicesVault | select Name,Type,Location,ResouceGroupName,Properties

$vault = Get-AzureRmRecoveryServicesVault -Name vaultPsconf01

$path = "C:\ASR"
Get-AzureRmRecoveryServicesVaultSettingsFile -Vault $vault -Path $path
Get-ChildItem -Path C:\ASR -Name *.VaultCredentials

$vaultPath = "C:\ASR\vaultPsconf01_2016-04-21T16-05-33.VaultCredentials"
$vaultPath
Import-AzureRmSiteRecoveryVaultSettingsFile -Path $vaultPath


$sitename = "MySiteTest"                #Definieren eines FriendlyName
New-AzureRmSiteRecoverySite -Name $sitename

& C:\ASR\AzureSiteRecoveryProvider.exe /x /qpu C:\ASR\

$BinPath = $env:SystemDrive+"\Program Files\Microsoft System Center 2012 R2\Virtual Machine Manager\bin"
$encryptionFilePath = "C:\ASR\DRConfigurator.exe /r /Credentials $VaultSettingFilePath /vmmfriendlyname $env:COMPUTERNAME /dataencryptionenabled $encryptionFilePath /startvmmservice"


$StorageAccountName = "psconf2016storageacc" #StorageAccountname
$StorageAccountGeo  = "West Europe"  
$ResourceGroupName =  “PSconf01”            #ResourceGroupName 
$RecoveryStorageAccount = New-AzureRmStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -Type “Standard_GRS” -Location $StorageAccountGeo

& C:\ASR\marsagentinstaller.exe /q /nu

Invoke-Command -ComputerName HV01 {& C:\Scripts\marsagentinstaller.exe /q /nu}
Invoke-Command -ComputerName HV02 {& C:\Scripts\marsagentinstaller.exe /q /nu}

$ReplicationFrequencyInSeconds = "300";     #options are 30,300,900
$PolicyName = “replicapolicyps2016”
$Recoverypoints = 6                 #specify the number of recovery points 

$SubscriptionName = 'Visual Studio Premium bei MSDN' 
$MySubscription = Select-AzureRmSubscription -SubscriptionName $SubscriptionName
$MySubscription.SubscriptionId

#Laden der Ressource Gruppe
#Laden Storage Account
$policryresult = New-AzureRmSiteRecoveryPolicy -Name $policyname -ReplicationProvider HyperVReplicaAzure -ReplicationFrequencyInSeconds $replicationfrequencyinseconds -RecoveryPoints $recoverypoints -ApplicationConsistentSnapshotFrequencyInHours 1 -RecoveryAzureStorageAccountId "/subscriptions/$sid/resourceGroups/$ResourceGroupName/providers/Microsoft.Storage/storageAccounts/$StorageAccountName"

$PrimaryCloud = "MyCloud02"
$protectionContainer = Get-AzureRmSiteRecoveryProtectionContainer -friendlyName $PrimaryCloud;



$policy = Get-AzureRmSiteRecoveryPolicy -FriendlyName $policyname
$associationJob  = Start-AzureRmSiteRecoveryPolicyAssociationJob -Policy $policy -PrimaryProtectionContainer $protectionContainer

$job = Get-AzureRmSiteRecoveryJob -Job $associationJob
if($job -eq $null -or $job.StateDescription -ne "Completed")
 {
$isJobLeftForProcessing = $true;
}




$VM = Get-SCVirtualMachine -VMMServer PSCONFSCVMM01.cdm.hyperv.ninja -Name "MyTestVM" | where {$_.VMHost.Name -eq "hv01.cdm.hyperv.ninja"}
$OperatingSystem = Get-SCOperatingSystem -VMMServer PSCONFSCVMM01.cdm.hyperv.ninja | where {$_.Name -eq "Windows Server 2012 R2 Standard"}
$UserRole = Get-SCUserRole -VMMServer PSCONFSCVMM01.cdm.hyperv.ninja  -Name "Administrator"

$CPUType = Get-SCCPUType -VMMServer PSCONFSCVMM01.cdm.hyperv.ninja | where {$_.Name -eq "3.60 GHz Xeon (2 MB L2 cache)"}

Set-SCVirtualMachine -VM $VM -Name "MyTestVM" -Description "" -OperatingSystem $OperatingSystem -Owner 'CDMHYPERV\Administrator' -UserRole $UserRole -CPUCount 1 -MemoryMB 512 -DynamicMemoryEnabled $false -MemoryWeight 5000 -VirtualVideoAdapterEnabled $false -CPUExpectedUtilizationPercent 20 -DiskIops 0 -CPUMaximumPercent 100 -CPUReserve 0 -NumaIsolationRequired $false -NetworkUtilizationMbps 0 -CPURelativeWeight 100 -HighlyAvailable $true -HAVMPriority 3000 -DRProtectionRequired $true -RecoveryPointObjective 300 -NumLock $false -BootOrder "CD", "IdeHardDrive", "PxeBoot", "Floppy" -CPULimitFunctionality $false -CPULimitForMigration $false -CPUType $CPUType -Tag "(none)" -QuotaPoint 1 -JobGroup 9822dd01-596b-427e-8524-4b18636f83a9 -RunAsynchronously -DelayStartSeconds 0 -BlockDynamicOptimization $false -EnableOperatingSystemShutdown $true -EnableTimeSynchronization $true -EnableDataExchange $true -EnableHeartbeat $true -EnableBackup $true -RunAsSystem -UseHardwareAssistedVirtualization $true 




