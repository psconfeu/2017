﻿# Using Static "new" method.
[PsconfGuest] $Hansolo = [PsconfGuest]::new("Hansolo", 13)

# Using New-Object. Parameters for Argument list are positional and required by the constructor.
[PsconfGuest] $Luke = New-Object PsconfGuest -ArgumentList "Luke", 42

# Using a HashTable. Note: requires default or parameterless constructor.
[PsconfGuest] $Vader = [PsconfGuest]@{
    Alias = "Vader";
    AttendeNr = 999;
}

# Dynamic Object Type using a variable name.
$Type = "PsconfGuest"
$Lea = New-Object -TypeName $Type

# Static Attribut auslesen
$Hansolo::Conference

# Anpassen Static Attribut ueber Klasse
[PsconfGuest]::Conference = "Blub"

# Static Attribut auslesen
$Hansolo::Conference