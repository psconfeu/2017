﻿class Overload
{
    # Calls Overloaded Method
    static [String] SayHello ()
    {
        return [Overload]::SayHello("There")
    }

    static [String] SayHello ([String] $Name)
    {
        return "Hello {0}!" -f $Name
    }
}