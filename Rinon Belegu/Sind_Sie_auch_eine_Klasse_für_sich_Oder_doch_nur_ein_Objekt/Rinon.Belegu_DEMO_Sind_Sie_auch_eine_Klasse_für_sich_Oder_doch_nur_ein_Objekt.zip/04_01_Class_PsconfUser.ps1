﻿class PsconfGuest
{
    # Properties
    [String] $Alias
    [int32] $AttendeNr

    # Static Properties
    static [String] $Conference = "PSConfEu 2017"

    # Hidden Properties
    hidden [String] $RealName

    # Parameterless Constructor
    PsconfGuest ()
    {
    }

    # Constructor
    PsconfGuest ([String] $Alias, [int32] $AttendeNr)
    {
        $this.Alias = $Alias
        $this.AttendeNr = $AttendeNr
    }

    # Method
    [String] getAlias()
    {
       return $this.Alias
    }

    # Static Method
    static [String] getConf()
    {
        return [PsconfGuest]::Conference
    }

    # ToString Method
    [String] ToString()
    {
        return $this.Alias + ":" + $this.AttendeNr
    }
}