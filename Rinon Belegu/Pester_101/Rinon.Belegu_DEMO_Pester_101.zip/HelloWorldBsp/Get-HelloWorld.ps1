﻿function Get-HelloWorld {

'Hello World!'

}

