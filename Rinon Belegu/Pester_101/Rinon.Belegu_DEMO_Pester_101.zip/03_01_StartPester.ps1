﻿# Pester Module suchen
Find-Module Pester

# Installieren von Pester
Install-Module Pester -Scope CurrentUser -Force

# Ein erster Blick

Import-Module -Name Pester
Get-Module -Name Pester | Select -ExpandProperty ExportedCommands

# Let's play Around

New-Item C:\Pester -ItemType Directory
Set-Location C:\Pester

# Hello World - 101

New-Fixture -Path HelloWorldBsp -Name Get-HelloWorld

Set-Location .\HelloWorldBsp

psedit .\Get-HelloWorld.Tests.ps1
psedit .\Get-HelloWorld.ps1



# Steuerung Testergebinsse

Describe "Teststati" {
It "Zeigt 1" {
    1 | Should be 1
    }
It -Skip "Checks the database" {
    Test-DBConnect | Should BeOfType System.Data.SqlClient.SqlConnection
    }
It -Pending "Lorem Ipsum" {
    }
}

# Forciert Invoke-Pester -Strict -> Failed

# Be and BeExactly

Describe "nicht Exakt"{
    It "nicht Exakt"{
        "psconfEU" | Should Be "psconfEU"
    }
    It "nicht Exakt"{
        "psconfEU" | Should Not Be "psconfeu"
    }
}

Describe "Exakt"{
    It "Exakt"{
        "psconfEU" | Should BeExactly "psconfEU"
    }
    It "Exakt"{
        "psconfEU" | Should Not BeExactly "psconfeu"
    }
}

# BeLessThan, BeGreaterThan

Describe "Less or Greater"{
    It "Greater"{
        1 | Should BeGreaterThan 0
    }
    It "LessThan"{
        1 | Should BeLessThan 2
    }
}

# Wildcard Vergleiche

Describe "WildCard"{
    It "enthaelt"{
        "psconfEU" | Should BeLike "*co*"
    }
    It "genau"{
        "psconfEU" | Should BeLikeExactly "*fE*"
    }
    It "regex Match Visa"{
        4222222222222 | Should Match "[456][0-9]{3}[0-9]{4}"
    }
}

# Credit Card examples https://www.paypalobjects.com/en_US/vhelp/paypalmanager_help/credit_card_numbers.htm
# http://www.regular-expressions.info/creditcard.html

# Ueberpruefen auf Typ

Describe "Typ"{
    It "String"{
        "psconfEU" | Should BeOfType System.String
    }
    It "pscustomobject"{
        [pscustomobject]@{Property = 'foo'} |Should BeOftype 'pscustomobject'
    }
}

# Auf Throw ueberpruefen


Describe "curly braces"{
    It "own throw"{
        { throw "psconfEU 2017 Rockz" } | Should throw "psconfEU 2017 Rockz"
    }
    It "Call"{
        { Get-Item -Path Traumland} | Should throw
    }
        It "Pass Call"{
        { Get-Item -Path Traumland -ErrorAction Stop } | Should throw
    }

    It "fail"{
        { throw "foo" } |Should throw "LoremIpsum"
    }
}

# Existenz

Describe "Object Existiert"{
    It "Windows Ordner ist daa"{
        "C:\Windows" | Should Exist
    }
}

# Inhalt ueberpruefen

Describe "Inhalt"{
    BeforeAll {
        Add-Content -Path 'TestDrive:\foo.txt' -Value 'psconfEU2017 RockZ!'
     }
    It "File beinhaltet rockz"{
        'TestDrive:\foo.txt' | Should Contain rockz
    }
    It "File beinhaltet genau RockZ"{
        'TestDrive:\foo.txt'| Should ContainExactly RockZ
    }
        It "File beinhaltet genau RockZ"{
        'TestDrive:\foo.txt'| Should not ContainExactly psconfeU2017
    }
}

# Nicht NullOrEmpty 

Describe "NullOrEmpty"{
    It "Gibt etwas zurueck"{
        Get-Process | Should Not BeNullOrEmpty
    }
}

# Array

Describe "NullOrEmpty"{
    It "Gibt etwas zurueck"{
        @(0,1,2,3,4,5) -contains '3' | Should be $true
    }
}

# Mock Example 01

function Get-FileNames(){

    Get-ChildItem | Where Name -Like *.txt | Select -ExpandProperty Name

}


 	
	Describe 'Get-FileNames' {
	 
	    It 'Gibt nur die eine TxT-Datei Zurueck' {
	        Mock Get-ChildItem {
	             [PSCustomObject]@{ Name = 'psconfeu01.txt' }
	        }
	        Get-FileNames | Should Be 'psconfeu01.txt'
	    }
	 
	    It 'Gibt TxT-Datei zurueck falls eine ubereinstimmt' {
	        Mock Get-ChildItem {
	            [PSCustomObject]@{ Name = 'psconfeu201.txt' },
	            [PSCustomObject]@{ Name = 'psconfeu2017.doc' }
	        }
	        Get-FileNames | Should Be 'psconfeu201.txt'
	    }
	 
	    It 'Keine Rueckgabe, da keine TxT-Dateien' {
	        Mock Get-ChildItem {
	            [PSCustomObject]@{ Name = 'psconfeu2017.doc' },
	            [PSCustomObject]@{ Name = 'mocktryout.doc' }
	        }
	        Get-FileNames | Should BeNullOrEmpty
	    }
	 
	}  


# Mock Example 02 #http://www.powershellmagazine.com/2014/09/30/pester-mock-and-testdrive/

function Restart-InactiveComputer
{
    if (-not ( Get-Process explorer -ErrorAction SilentlyContinue ) )
    {
        Restart-Computer -Force
    }
}


Describe "Restart-InactiveComputer" {
   Mock Restart-Computer { "Restarting!" }
   Context "Computer should restart" {
      It "Restarts the computer" {
         Mock Get-Process {} -ParameterFilter { $Name -eq "Explorer" }
         Restart-InactiveComputer | Out-Null
         Assert-MockCalled Restart-Computer -Exactly 1 -parameterFilter { $Force }
      }
   }
 
   Context "Computer should not restart" {
      It "Does not restart the computer if user is logged on" {
          Mock Get-Process { $true } -ParameterFilter { $Name -eq "Explorer" }
          Restart-InactiveComputer | Out-Null
          Assert-MockCalled Restart-Computer -Exactly 0 -parameterFilter { $Force }
      }
   }
}


# Code Coverage

<#

function Get-HelloName {

'Hello TryOut'


}

#>

Invoke-Pester -Script .\Get-HelloWorld.Tests.ps1 -CodeCoverage .\Get-HelloWorld.ps1

