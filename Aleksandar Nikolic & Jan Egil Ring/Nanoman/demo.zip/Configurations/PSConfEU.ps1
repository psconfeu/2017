﻿configuration PSConfEU {

Import-DscResource -ModuleName AuditPolicyDsc, SecurityPolicyDSC, GpRegistryPolicy, PSDesiredStateConfiguration

    node BaseConfig {
  

      SecurityTemplate baselineInf
      {

        Path = "C:\temp\Configurations\Assets\sec.inf"
        # https://msdn.microsoft.com/powershell/dsc/singleinstance
        IsSingleInstance = "Yes"

      }


      AuditPolicyCsv baselineCsv
      {

        IsSingleInstance = "Yes"
        CsvPath = "C:\temp\Configurations\Assets\audit.csv"

      }


      RegistryPolicy baselineGpo
      {

        Path = "C:\temp\Configurations\Assets\registry.pol"

      }


      UserRightsAssignment AccessComputerFromNetwork
      {

        Policy   = 'Access_this_computer_from_the_network'
        Identity = "Builtin\Administrators" #'PSCONF\Domain Users'

      }
  
       UserRightsAssignment LogOnAsAService
       {

        Policy   = 'Log_on_as_a_service'
        Identity = 'Builtin\Administrators' #'PSCONF\_svc_psconfapp'

       }

    }


}