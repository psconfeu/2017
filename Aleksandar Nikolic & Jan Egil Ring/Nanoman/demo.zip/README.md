# PSConfEU2017Nano

A PowerShell demo module for the session "Look! Up in the sky! It's a bird. It's a plane. It's Nanoman!" by Aleksandar Nikolic & Jan Egil Ring

Automate All the Things!