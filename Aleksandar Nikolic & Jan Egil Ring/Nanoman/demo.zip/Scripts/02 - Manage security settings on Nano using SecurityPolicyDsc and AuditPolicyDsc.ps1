﻿# Toggle regions: Ctrl + M

#region Demo setup
Write-Warning 'This is a demo script which should be run line by line or sections at a time, stopping script execution'

break

<#

    Author:      Jan Egil Ring
    Name:        02 - Manage security settings on Nano using SecurityPolicyDsc and AuditPolicyDsc.ps1
    Description: This demo script is part of the presentation 
                 Look! Up in the sky! It's a bird. It's a plane. It's Nanoman!
                 
#>

# https://blogs.msdn.microsoft.com/powershell/2016/05/09/new-security-cmdlets-in-nano-server/
Get-Command -Module SecurityCmdlets

gpedit.msc

# https://blogs.msdn.microsoft.com/powershell/2017/02/21/managing-security-settings-on-nano-server-with-dsc/

Install-Module SecurityPolicyDsc, AuditPolicyDsc, GpRegistryPolicy -Force

$SecurityPolicyExportPath = 'D:\GitHub\PSConfEU2017Nano\Configurations\Assets\sec.inf'
Backup-SecurityPolicy -Path $SecurityPolicyExportPath

psedit $SecurityPolicyExportPath

Restore-SecurityPolicy -Path $SecurityPolicyExportPath

$AuditPolicyExportPath = 'D:\GitHub\PSConfEU2017Nano\Configurations\Assets\audit.csv'
Backup-AuditPolicy -Path $AuditPolicyExportPath

psedit $AuditPolicyExportPath

Restore-AuditPolicy -Path $AuditPolicyExportPath

$GPRegistryPolicyExportPath = 'D:\GitHub\PSConfEU2017Nano\Configurations\Assets\registry.pol'
Export-GPRegistryPolicy -LocalMachine -Path $GPRegistryPolicyExportPath

psedit $GPRegistryPolicyExportPath

Import-GPRegistryPolicy -Path $GPRegistryPolicyExportPath -LocalMachine

. D:\GitHub\PSConfEU2017Nano\Configurations\PSConfEU.ps1
psedit D:\GitHub\PSConfEU2017Nano\Configurations\PSConfEU.ps1

PSConfEU -OutputPath D:\temp\SecurityBaseline

Start-DscConfiguration -Path D:\temp\SecurityBaseline -ComputerName PSConfEUDemoVM01

psedit D:\temp\SecurityBaseline\BaseConfig.mof

Import-AzureRmAutomationDscNodeConfiguration -ConfigurationName PSConfEU -Path D:\temp\SecurityBaseline\BaseConfig.mof

Enter-PSSession -ComputerName HPV-JR-01

$VMCredential = Get-Credential
Enter-PSSession -VMName PSConfEUDemoVM01 -Credential $VMCredential

Get-DscLocalConfigurationManager

Get-DscConfigurationStatus

Get-DscConfiguration

Test-DscConfiguration -Verbose -Detailed

Exit-PSSession
Exit-PSSession

# Pending pull request: https://github.com/PowerShell/SecurityPolicyDsc/pull/32 (Added SecuritySetting resource)
# Check out the following if it`s not merged yet: https://github.com/bobbytreed/SecurityPolicyDsc/blob/dev/DSCResources/MSFT_SecuritySetting/MSFT_SecuritySetting.psm1
# Makes it possible to set granular properties such as MinimumPasswordAge and so on directly in the DSC configuration (avoiding the inf-file)

#endregion