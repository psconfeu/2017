﻿# OpsMachine
Get-SCVirtualMachine -Name PSConfEUDemoVM01 | Stop-SCVirtualMachine -Force | Remove-SCVirtualMachineGet
Get-AzureRmAutomationDscNode | Where-Object name -eq NANOVM | Unregister-AzureRmAutomationDscNode -Force

<# Manual actions

#>