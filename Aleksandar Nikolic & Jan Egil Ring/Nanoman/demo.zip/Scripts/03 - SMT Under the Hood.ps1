# Toggle regions: Ctrl + M

#region Demo setup
Write-Warning 'This is a demo script which should be run line by line or sections at a time, stopping script execution'

break

<#

    Author:      Aleksandar Nikolic & Jan Egil Ring
    Name:        03 - SMT Under the Hood.ps1
    Description: This demo script is part of the presentation 
                 Look! Up in the sky! It's a bird. It's a plane. It's Nanoman!
                 
#>

# Management Tools Task Manager WMI Provider
# https://msdn.microsoft.com/en-us/library/dn958299(v=vs.85).aspx

$mtnamespace = 'root/microsoft/windows/managementtools'

Get-CimClass -Namespace $mtnamespace

Get-WmiProvider | where Namespace -like *ManagementTools*

Get-CimInstance -Namespace $mtnamespace -ClassName __Provider | Select-Object name

Invoke-CimMethod -Namespace $mtnamespace -ClassName MSFT_MTRegistryTasks -MethodName Search -Arguments @{keyname = 'HKEY_LOCAL_MACHINE\SOFTWARE'; value = 'winrm'}

$results = Invoke-CimMethod -Namespace $mtnamespace -ClassName MSFT_MTRegistryTasks -MethodName Search -Arguments @{keyname = 'HKEY_LOCAL_MACHINE\SOFTWARE'; value = 'winrm'}

$results.ItemValue | Format-List Name,Data

Get-CimInstance -Namespace $mtnamespace -ClassName MSFT_MTProcess

Get-CimInstance -Namespace $mtnamespace -ClassName MSFT_MTProcess | where elevated -eq $false |
select name


Get-CimInstance -Namespace $mtnamespace -ClassName MSFT_MTNetworkAdapter

Get-CimInstance -Namespace $mtnamespace -ClassName MSFT_MTMemorySummary

Get-CimInstance -Namespace $mtnamespace -ClassName MSFT_MTProcessorSummary

Get-CimInstance -Namespace $mtnamespace -ClassName MSFT_MTDisk



# Inspect logs after performing SMT actions in the Azure Portal

Get-WinEvent -LogName Microsoft-Windows-WMI-Activity/Debug -Oldest |
Where-Object message -like "*ServerManager*" | Select-Object -ExpandProperty message

Get-WinEvent -LogName Microsoft-ServerManagementTools-Gateway/Debug -Oldest |
Where-Object message -like "*Accessing Cached Cim Class*" | Select-Object -ExpandProperty message