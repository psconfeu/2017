﻿# Toggle regions: Ctrl + M

#region Demo setup
Write-Warning 'This is a demo script which should be run line by line or sections at a time, stopping script execution'

break

<#

    Author:      Jan Egil Ring
    Name:        01 - DSC bootstrapping.ps1
    Description: This demo script is part of the presentation 
                 Look! Up in the sky! It's a bird. It's a plane. It's Nanoman!
                 
#>

Import-Module -Name D:\GitHub\PSConfEU2017Nano\Module\PSConfEU2017Nano.psd1

Get-Command -Module PSConfEU2017Nano

#region MOF-injection

# Reference: https://msdn.microsoft.com/en-us/powershell/dsc/bootstrapdsc

$DSCMetaConfiguration = 'D:\GitHub\PSConfEU2017Nano\MOF-files\PSConfEU2017.meta.mof'
$TemplateVHDX = 'E:\Hyper-V\Templates\NanoVM.vhdx'

psedit $DSCMetaConfiguration

New-PSConfHyperVVM -VMName PSConfEUDemoVM01 -TemplateVHDX $TemplateVHDX -DSCMetaConfiguration $DSCMetaConfiguration

Connect-VMConsole -VMName  PSConfEUDemoVM01 -VMHost HPV-JR-01

#endregion