﻿function New-PSConfHyperVVM {

  param (
    $VMName,
    $HyperVHost = 'HPV-JR-01',
    $ISOPath,
    $MemoryMaximumBytes = 2GB,
    $MemoryStartupBytes = 1GB,
    $SwitchName = 'LAN',
    $NewVMPath,
    $VMGeneration = '2',
    $NewVHDSizeBytes = 20GB,
    $CPUCount = '2',
    $TemplateVHDX,
    $DSCMetaConfiguration
    
  )


  if ($NewVMPath -eq $null) {
  
    $Drive = Get-Volume -CimSession $HyperVHost | Out-GridView -Title 'Select drive for new VM' -PassThru
    $NewVMPath = $Drive.DriveLetter + ':\Hyper-V\'
  
  }
  
 
  
  $NewVMParameters = @{

    CimSession = $HyperVHost
    Name = $VMName
    SwitchName = $SwitchName
    Path = $NewVMPath
    MemoryStartupBytes = $MemoryStartupBytes
    Generation = $VMGeneration

  }
   
   if ($TemplateVHDX -eq $null) {
    
     $NewVMParameters.Add('NewVHDPath',($NewVMPath + $VMName + '\' + $VMName + '_disk_1.vhdx'))
     $NewVMParameters.Add('NewVHDSizeBytes',$NewVHDSizeBytes)

   }
   
    
  $VM = New-VM @NewVMParameters

  $VM | Set-VMProcessor -Count $CPUCount
  $VM | Set-VM -DynamicMemory -MemoryMaximumBytes $MemoryMaximumBytes
  $VM | Set-VM -AutomaticStopAction ShutDown
 
   if ($TemplateVHDX ) {
    
     $NewVHDPath = ($NewVMPath + $VMName + '\' + $VMName + '_disk_1.vhdx')
     $null = New-VHD -Differencing -Path $NewVHDPath -ParentPath $TemplateVHDX -CimSession $HyperVHost
     $VM | Add-VMHardDiskDrive -ControllerType SCSI -ControllerNumber 0 -ControllerLocation 0 -Path $NewVHDPath

    $VM | Set-VMFirmware -BootOrder $VM.HardDrives[0]

   }
 
  if ($ISOPath) {
  
    $VM | Add-VMDvdDrive -Path $ISOPath
    Set-VMDvdDrive -VMName $VMName -Path $ISOPath -CimSession $HyperVHost
  
    $VM | Set-VMFirmware -BootOrder $VM.DVDDrives[0],$VM.HardDrives[0]
  
  }
 
 if ($DSCMetaConfiguration) {
 
   function Get-UNCPath {param(	[string]$HostName,
        [string]$LocalPath)
     $NewPath = $LocalPath -replace(":","$")
     #delete the trailing \, if found
     if ($NewPath.EndsWith("\")) {
       $NewPath = [Text.RegularExpressions.Regex]::Replace($NewPath, "\\$", "")
     }
     "\\$HostName\$NewPath"
   }

   $NewVHDUNCPath = Get-UNCPath -HostName $HyperVHost -LocalPath $NewVHDPath
 
   $before = Get-Volume
   $VHDMount = Mount-DiskImage -ImagePath $NewVHDUNCPath -PassThru -StorageType VHDX
   $after = Get-Volume
   $VMSystemDrive = (Compare-Object $before $after -Passthru -Property DriveLetter | where DriveLetter).DriveLetter
   
   do
   {
   
     Write-Host "Waiting for VM system drive $VMSystemDrive to be available as a PSDrive" -ForegroundColor Yellow
   
     $drivetest = Get-PSDrive -Name $VMSystemDrive -Scope Global -ErrorAction Ignore
     
     Start-Sleep 2
     
   } until ($drivetest)
   
   
   $VMSystemPath = Join-Path -Path ($VMSystemDrive + ':\') -ChildPath Windows\System32\Configuration

   Copy-Item -Path $DSCMetaConfiguration -Destination (Join-Path -Path $VMSystemPath -ChildPath MetaConfig.mof)

   Dismount-DiskImage -InputObject $VHDMount
 
 }


  $VM | Start-VM -Passthru

}