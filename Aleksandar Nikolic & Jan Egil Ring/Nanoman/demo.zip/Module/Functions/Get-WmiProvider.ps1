function Get-WmiProvider  {
param (
    $ns = "root"
)
   Get-CimInstance -Namespace $ns -ClassName "__NAMESPACE" |
   foreach {
       Get-CimInstance -NameSpace $currNameSpace -ClassName __Win32Provider | select @{n="Namespace";e=    {$("$ns\" + $_.Name)}},@{n="Provider";e={$_.Name}}
       Get-WmiProvider $("$ns\" + $_.Name) 
   } 
}