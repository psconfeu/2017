# FishTank
## about_FishTank

# SHORT DESCRIPTION
Manage all your fish tanks

# LONG DESCRIPTION

FishTank provides a way to

- Completely automate the management of your fish tanks
