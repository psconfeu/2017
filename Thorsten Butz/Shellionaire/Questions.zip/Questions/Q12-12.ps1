﻿# Q 12/12

## Which of these will return 1.12 (1,12 in de-DE)? 

[double](2.25 * 0.5)
[math]::round(2.25 * 0.5,2)
"{0:0.00}" -f (2.25 * 0.5)
$NUL # None of the above