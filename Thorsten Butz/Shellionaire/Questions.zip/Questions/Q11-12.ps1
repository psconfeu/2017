﻿# Q 11/12

## Which of these is a valid verb (as validated by "Get-Verb")?

Attach
Build
Complete
Exec