﻿# Q 04/12

## Which of these is not sold on Amazon
'Powershell in a Month of Lunches'
'The Powershell Cookbook'
'The PowerShell in Bottle'
'Powershell in Action'