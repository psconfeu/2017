﻿# Q 05/12

## Which of these terms is $true? 
1 + 1 -eq 5
1 * 1 -gt 6
1 - 1 -like 'abc'
1 / 1 -lt 10