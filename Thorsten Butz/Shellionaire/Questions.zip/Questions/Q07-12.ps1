﻿# Q 07/12

## What's the result of:
('Donald.Duck').replace('d','t')

# Choose your answer:
'tonalt.tuck'
'Donald.Duck'
'Tonalt.Tuck'
'Donalt.Duck'