﻿# Q 03/12

## PowerShell modules can be published on the
'PowerShell Wall'
'PowerShell Esculator'
'PowerShell Elevator'
'PowerShell Gallery'