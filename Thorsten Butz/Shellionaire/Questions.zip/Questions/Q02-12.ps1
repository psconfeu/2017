﻿# Q 02/12

## Which of these is a Cmdlet?
Coffee-Cup
Tee-Object
Juice-Glass
Water-Bottle