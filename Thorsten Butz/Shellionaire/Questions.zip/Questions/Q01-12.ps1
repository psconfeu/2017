﻿# Q 01/12

## Who influenced the development of the PowerShell significantly? 
'Jeffrey Snover' 	
'Thomas Jefferson'
'Donald Duck'
'Donald Trump'