﻿# draw 
Get-Random -Minimum 1 -Maximum 50

#region Selection

    ## How many commands provides the "Active Directory"-Module on my Computer (Windows 10, RSAT 1.2)?
    (Get-Command -Module 'Active Directory').count

#endregion