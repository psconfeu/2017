﻿# Q 06/12

## Whats the result of: 
'1' + 1 + '1'

# Choose your answer:
3
11
31
111