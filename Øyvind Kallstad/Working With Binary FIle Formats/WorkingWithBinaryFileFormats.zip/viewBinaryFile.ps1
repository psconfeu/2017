$imageFile = '.\TestImages\ct1n0g04.png'

# View ascii representation of binary data
Get-Content -Path $imageFile -Raw

# View bytes
Get-Content -Path $imageFile -Raw -Encoding Byte
(Get-Content -Path $imageFile -Raw -Encoding Byte) -join ' '

# Pretty!
Get-Content -Path $imageFile -Raw | Format-Hex