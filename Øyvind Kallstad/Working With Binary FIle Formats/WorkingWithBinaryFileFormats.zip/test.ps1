#$imagePath = '.\TestImages\basi0g01.png'
#$imagePath = '.\TestImages\cs3n3p08.png' #PLTE
#$imagePath = '.\TestImages\cdfn2c08.png' #pHYs
#$imagePath = '.\TestImages\cdun2c08.png' #pHYs
#$imagePath = '.\TestImages\ccwn2c08.png' #cHRM
#$imagePath = '.\TestImages\ch1n3p04.png' #hIST
#$imagePath = '.\TestImages\cm0n0g04.png' #tIME
$imagePath = '.\TestImages\ct1n0g04.png' #tEXT
#$imagePath = '.\TestImages\cten0g04.png' #iTXt
#$imagePath = '.\TestImages\ctzn0g04.png' #zTXt
#$imagePath = '.\TestImages\ctfn0g04.png' #iTXt lang=fi
#$imagePath = '.\TestImages\ps1n0g08.png' #sPLT
#$imagePath = '.\TestImages\ps1n2c16.png'

. .\crc.ps1

function Read-IHDR ([byte[]]$data) {

    $width = $data[0..3]
    $height = $data[4..7]
    $bitDepth = $data[8]
    $colorType = $data[9]
    $compressionMethod = $data[10]
    $filterMethod = $data[11]
    $interlacedMethod = $data[12]

    [array]::Reverse($width)
    [array]::Reverse($height)

    switch ($colorType) {
        0 {$colorTypeString = 'Greyscale'}
        2 {$colorTypeString = 'Truecolour'}
        3 {$colorTypeString = 'Indexed-colour'}
        4 {$colorTypeString = 'Greyscale with alpha'}
        6 {$colorTypeString = 'Truecolour with alpha'}
        DEFAULT {$colorTypeString = 'UNKNOWN'}
    }

    switch ($interlacedMethod) {
        0 {$interlacedMethodString = 'no interlace'}
        1 {$interlacedMethodString = 'Adam7'}
        DEFAULT {$interlacedMethodString = 'UNKNOWN'}
    }

    Write-Output ([PSCustomObject] [Ordered] @{
        Width = [System.BitConverter]::ToUInt32($width,0)
        Height = [System.BitConverter]::ToUInt32($height,0)
        BitDepth = $bitDepth
        ImageType = $colorTypeString
        CompressionMethod = $compressionMethod
        FilterMethod = $filterMethod
        InterlaceMetod = $interlacedMethodString
    })
}

function Read-gAMA ([byte[]]$data) {
    $gama = $data
    [array]::Reverse($gama)
    [double]$gamaValue = ([System.BitConverter]::ToUInt32($gama,0)) / 100000
    Write-Output $gamaValue
}

function Read-PLTE ([byte[]]$data) {
    $colors = @()
    for ($i = 0; $i -lt $data.Length; $i = $i + 3) {
        $colors += ([PSCustomObject] [Ordered] @{
            Red = $data[$i]
            Green = $data[$i+1]
            Blue = $data[$i+2]
        })
    }
    Write-Output $colors
}

function Read-hIST ([byte[]]$data) {
    for ($i = 0; $i -lt $data.Length; $i = $i + 2) {
        $frequencyBytes = $data[$i..($i+1)]
        [array]::Reverse($frequencyBytes)
        Write-Output ([System.BitConverter]::ToUInt16($frequencyBytes,0))
    }
}

function Read-pHYs ([byte[]]$data) {
    $ppuXBytes = $data[0..3]
    $ppuYBytes = $data[4..7]
    $unit = $data[8]

    [array]::Reverse($ppuXBytes)
    [array]::Reverse($ppuYBytes)

    switch($unit) {
        0 {$unitString = 'UNKNOWN'}
        1 {$unitString = 'metre'}
        DEFAULT {$unitString = 'UNKNOWN'}
    }

    Write-Output ([PSCustomObject] [Ordered] @{
        PixelsPerUnitX = [System.BitConverter]::ToUInt32($ppuXBytes,0)
        PixelsPerUnitY = [System.BitConverter]::ToUInt32($ppuYBytes,0)
        Unit = $unitString
    })
}

function Read-cHRM ([byte[]]$data) {
    $whitePointX = $data[0..3]
    $whitePointY = $data[4..7]
    $redX = $data[8..11]
    $redY = $data[12..15]
    $greenX = $data[16..19]
    $greenY = $data[20..23]
    $blueX = $data[24..27]
    $blueY = $data[28..31]

    [array]::Reverse($whitePointX)
    [array]::Reverse($whitePointY)
    [array]::Reverse($redX)
    [array]::Reverse($redY)
    [array]::Reverse($greenX)
    [array]::Reverse($greenY)
    [array]::Reverse($blueX)
    [array]::Reverse($blueY)

    Write-Output ([PSCustomObject] [Ordered] @{
        WhitePointX = ([System.BitConverter]::ToUInt32($whitePointX,0))/100000
        WhitePointY = ([System.BitConverter]::ToUInt32($whitePointY,0))/100000
        RedX = ([System.BitConverter]::ToUInt32($redX,0))/100000
        RedY = ([System.BitConverter]::ToUInt32($redY,0))/100000
        GreenX = ([System.BitConverter]::ToUInt32($greenX,0))/100000
        GreenY = ([System.BitConverter]::ToUInt32($greenY,0))/100000
        BlueX = ([System.BitConverter]::ToUInt32($blueX,0))/100000
        BlueY = ([System.BitConverter]::ToUInt32($blueY,0))/100000
    })

}

function Read-tIME ([byte[]]$data) {
    $yearBytes = $data[0..1]
    $month = $data[2]
    $day = $data[3]
    $hour = $data[4]
    $minute = $data[5]
    $second = $data[6]

    [array]::Reverse($yearBytes)

    $dateTime = [System.DateTime]::new([System.BitConverter]::ToUInt16($yearBytes,0),$month,$day,$hour,$minute,$second,[System.DateTimeKind]::Utc)

    Write-Output $dateTime
}

function Read-tEXT ([byte[]]$data) {
    $keywordBytes = @()
    $textStringBytes = @()
    $separatorFound = $false
    for ($i = 0; $i -lt $data.Length; $i++) {
        if ($data[$i] -eq 0) {
            $separatorFound = $true
        }
        else {
            if (-not($separatorFound)) {
                $keywordBytes += $data[$i]
            }
            else {
                $textStringBytes += $data[$i]
            }
        }
    }

    $keyword = [System.Text.Encoding]::ASCII.GetString($keywordBytes)
    $textString = [System.Text.Encoding]::ASCII.GetString($textStringBytes)

    Write-Output (@{
        "$($keyword)" = $textString
    })
}

function Read-iTXt ([byte[]]$data) {
    $i = 0

    $keywordBytes = @()
    do {
        [byte]$thisByte = $data[$i]
        $i++
        if (-not($thisByte -eq 0)) {
            $keywordBytes += $thisByte
        }
    } until ($thisByte -eq 0)
    $keywordString = [System.Text.Encoding]::UTF8.GetString($keywordBytes)

    $compressionFlag = $data[$i]
    $i++
    switch ($compressionFlag) {
        0 {$compressionFlagString = 'Uncompressed text'}
        1 {$compressionFlagString = 'Compressed text'}
        DEFAULT {$compressionFlagString = 'UNKNOWN'}
    }

    $compressionMethod = $data[$i]
    $i++
    if ($compressionMethod -eq 0) {$compressionMethodString = 'zlib datastream with deflate compression'}

    $languageTagBytes = @()
    do {
        [byte]$thisByte = $data[$i]
        $i++
        if (-not($thisByte -eq 0)) {
            $languageTagBytes += $thisByte
        }
    } until ($thisByte -eq 0)
    $languageTagString = [System.Text.Encoding]::UTF8.GetString($languageTagBytes)

    $translatedKeywordBytes = @()
    do {
        [byte]$thisByte = $data[$i]
        $i++
        if (-not($thisByte -eq 0)) {
            $translatedKeywordBytes += $thisByte
        }
    } until ($thisByte -eq 0)
    $translatedKeywordString = [System.Text.Encoding]::UTF8.GetString($translatedKeywordBytes)

    $textBytes = @()
    do {
        [byte]$thisByte = $data[$i]
        $i++
        $textBytes += $thisByte
    } until ($i -eq $data.Length)
    $textString = [System.Text.Encoding]::UTF8.GetString($textBytes)

    Write-Output ([PSCustomObject] [Ordered] @{
        Keyword = $keywordString
        CompressionFlag = $compressionFlagString
        CompressionMethod = $compressionMethodString
        Language = $languageTagString
        TranslatedKeyword = $translatedKeywordString
        Text = $textString
    })
}

function Read-zTXt ([byte[]]$data) {
    $i = 0

    $keywordBytes = @()
    do {
        [byte]$thisByte = $data[$i]
        $i++
        if (-not($thisByte -eq 0)) {
            $keywordBytes += $thisByte
        }
    } until ($thisByte -eq 0)
    $keywordString = [System.Text.Encoding]::UTF8.GetString($keywordBytes)

    $compressionMethod = $data[$i]
    $i++
    if ($compressionMethod -eq 0) {$compressionMethodString = 'zlib datastream with deflate compression'}

    $compressedTextDatastream = @()
    do {
        [byte]$thisByte = $data[$i]
        $i++
        $compressedTextDatastream += $thisByte
    } until ($i -eq $data.Length)

    Write-Output ([PSCustomObject] [Ordered] @{
        Keyword = $keywordString
        CompressionMethod = $compressionMethodString
        CompressedTextDatastream = $compressedTextDatastream
    })

}

function Read-sPLT ([byte[]]$data) {
    $i = 0

    $paletteNameBytes = @()
    do {
        [byte]$thisByte = $data[$i]
        $i++
        if (-not($thisByte -eq 0)) {
            $paletteNameBytes += $thisByte
        }
    } until ($thisByte -eq 0)
    $paletteNameString = [System.Text.Encoding]::ASCII.GetString($paletteNameBytes)

    $sampleDepth = $data[$i]
    $i++

    $paletteData = @()

    do {
        switch ($sampleDepth) {
            8 {
                $red = $data[$i]; $i++
                $green = $data[$i]; $i++
                $blue = $data[$i]; $i++
                $alpha = $data[$i]; $i++
            }
            16 {
                $redBytes = $data[$i..($i+1)]; $i++; $i++
                $greenBytes = $data[$i..($i+1)]; $i++; $i++
                $blueBytes = $data[$i..($i+1)]; $i++; $i++
                $alphaBytes = $data[$i..($i+1)]; $i++; $i++
                [array]::Reverse($redBytes)
                [array]::Reverse($greenBytes)
                [array]::Reverse($blueBytes)
                [array]::Reverse($alphaBytes)
                $red = [System.BitConverter]::ToUInt16($redBytes,0)
                $green = [System.BitConverter]::ToUInt16($redBytes,0)
                $blue = [System.BitConverter]::ToUInt16($redBytes,0)
                $alpha = [System.BitConverter]::ToUInt16($redBytes,0)
            }
        }

        $frequencyBytes = $data[$i..($i+1)]
        $i++;$i++
        [array]::Reverse($frequencyBytes)
        $frequency = [System.BitConverter]::ToUInt16($frequencyBytes,0)

        $paletteData += ([PSCustomObject] [Ordered] @{
            Red = $red
            Green = $green
            Blue = $blue
            Alpha = $alpha
            Frequency = $frequency
        })
        #break
    } until ($i -ge $data.Length)

    Write-Output ([PSCustomObject] [Ordered] @{
        PaletteName = $paletteNameString
        SampleDepth = $sampleDepth
        PaletteData = $paletteData
    })
}

function Read-Chunk {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline, Position = 1)]
        [System.IO.BinaryReader] $Reader
    )

    $chunkStartPosition = $Reader.BaseStream.Position

    # Get length of chunk data field
    $chunkDataLengthBytes = $Reader.ReadBytes(4)
    if ([System.BitConverter]::IsLittleEndian) {
        [array]::Reverse($chunkDataLengthBytes)
    }
    $chunkDataLength = [System.BitConverter]::ToUInt32($chunkDataLengthBytes,0)

    # Get chunk type
    $chunkTypeBytes = $Reader.ReadBytes(4)
    $chunkType = [System.Text.Encoding]::Default.GetString($chunkTypeBytes)

    # Get chunk data
    if ($chunkDataLength -ne 0) {
        $chunkData = $Reader.ReadBytes($chunkDataLength)
    }

    # Get CRC
    $chunkCRC = $Reader.ReadBytes(4)
    [array]::Reverse($chunkCRC)
    $chunkCRC = [System.BitConverter]::ToUInt32($chunkCRC,0)

    $chunkEndPosition = $Reader.BaseStream.Position

    # Calculate and check CRC
    if ($chunkDataLength -ne 0) {
        [byte[]]$dataForCrcCheck = $chunkTypeBytes + $chunkData
    }
    else {
        [byte[]]$dataForCrcCheck = $chunkTypeBytes
    }
    $calculatedCRC = Get-CRC32 $dataForCrcCheck

    # Parse Chunk Data
    switch ($chunkType) {
        'IHDR' {$parsedData = Read-IHDR $chunkData}
        'gAMA' {$parsedData = Read-gAMA $chunkData}
        'PLTE' {$parsedData = Read-PLTE $chunkData}
        'pHYs' {$parsedData = Read-pHYs $chunkData}
        'cHRM' {$parsedData = Read-cHRM $chunkData}
        'hIST' {$parsedData = Read-hIST $chunkData}
        'tIME' {$parsedData = Read-tIME $chunkData}
        'tEXT' {$parsedData = Read-tEXT $chunkData}
        'iTXt' {$parsedData = Read-iTXt $chunkData}
        'zTXt' {$parsedData = Read-zTXt $chunkData}
        'sPLT' {$parsedData = Read-sPLT $chunkData}
    }

    switch ($chunkType) {
        'IHDR' {$typeDescription = 'Image header'}
        'PLTE' {$typeDescription = 'Palette'}
        'IDAT' {$typeDescription = 'Image data'}
        'IEND' {$typeDescription = 'Image trailer'}
        'tRNS' {$typeDescription = 'Transparency'}
        'cHRM' {$typeDescription = 'Primary chromaticities and white point'}
        'gAMA' {$typeDescription = 'Image gamma'}
        'iCCP' {$typeDescription = 'Embedded ICC profile'}
        'sBIT' {$typeDescription = 'Significant bits'}
        'sRGB' {$typeDescription = 'Standard RGB colour space'}
        'tEXt' {$typeDescription = 'Textual data'}
        'zTXt' {$typeDescription = 'Compressed textual data'}
        'iTXt' {$typeDescription = 'International textual data'}
        'bKGD' {$typeDescription = 'Background colour'}
        'hIST' {$typeDescription = 'Image histogram'}
        'pHYs' {$typeDescription = 'Physical pixel dimensions'}
        'sPLT' {$typeDescription = 'Suggested palette'}
        'tIME' {$typeDescription = 'Image last-modification time'}
        DEFAULT {$typeDescription = 'UNKNOWN'}
    }

    Write-Output ([PSCustomObject] [Ordered]@{
        Type = $chunkType
        Description = $typeDescription
        DataLength = $chunkDataLength
        Data_raw = $chunkData
        Data = $parsedData
        CRC = $chunkCRC
        CalculatedCRC = $calculatedCRC
        StartPosition = $chunkStartPosition
        EndPosition = $chunkEndPosition
    })
}

function Read-PNG {
    [CmdletBinding()]
    param (
        [Parameter(Position = 0, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [string] $Path
    )

    try {

        $resolvedPath = Resolve-Path -Path $Path

        $fileStream = New-Object -TypeName System.IO.FileStream -ArgumentList ($resolvedPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read)
        $fileReader = New-Object -TypeName System.IO.BinaryReader -ArgumentList $fileStream

        $fileSignature = $fileReader.ReadBytes(8)

        # check signature and break if not matching the PNG file signature
        if (-not ([System.BitConverter]::ToString($fileSignature) -eq '89-50-4E-47-0D-0A-1A-0A')) {
            Write-Warning 'File is not a PNG-file.'
            break
        }
        else {
            Write-Verbose "PNG Signature: $([System.BitConverter]::ToString($fileSignature))"
        }

        do {

            $chunk = $fileReader | Read-Chunk -Verbose:$VerbosePreference
            $chunk

        } until ($chunk.Type -eq  'IEND')
    }

    catch {
        Write-Warning $_
    }

    finally {
        $fileReader.Close()
        $fileReader.Dispose()
        $fileStream.Close()
        $fileStream.Dispose()
    }
}

<#

    Chunk layout:
    LENGTH + CHUNK TYPE + CHUNK DATA + CRC
    or
    LENGTH (=0) + CHUNK TYPE + CRC

    Critical chunks
    Shall appear in this order, except PLTE is optional

    IHDR (shall be first)
    PLTE (before first IDAT)
    IDAT (multiple allowed - chunks must be consecutive)
    IEND (shall be last)

    Ancillary chunks
    Need not appear in this order

    cHRM (Before PLTE and IDAT)
    gAMA (Before PLTE and IDAT)
    iCCP (Before PLTE and IDAT. If the iCCP chunk is present, the sRGB chunk should not be present.)
    sBIT (Before PLTE and IDAT)
    sRGB (Before PLTE and IDAT. If the sRGB chunk is present, the iCCP chunk should not be present.)
    bKGD (After PLTE; before IDAT)
    hIST (After PLTE; before IDAT)
    tRNS (After PLTE; before IDAT)
    pHYs (Before IDAT)
    sPLT (Before IDAT - multiple allowed)
    tIME
    iTXt (multiple allowed)
    tEXt (multiple allowed)
    zTXt (multiple allowed)
#>

Read-PNG -Path $imagePath
