$imageFile = '.\TestImages\ct1n0g04.png'

$resolvedPath = Resolve-Path -Path $imageFile

$fileStream = New-Object -TypeName System.IO.FileStream -ArgumentList ($resolvedPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read)
$fileReader = New-Object -TypeName System.IO.BinaryReader -ArgumentList $fileStream

# Get the length of the stream
$fileReader.BaseStream.Length

# Get the currente position of the stream
$fileReader.BaseStream.Position

# Read two bytes
$bytes = $fileReader.ReadBytes(2)

# See that the position changed
$fileReader.BaseStream.Position

# Set the position
$fileReader.BaseStream.Position = 0
$fileReader.BaseStream.Position

$res = . .\test.ps1

# Get text
[byte[]]$textChunk = $res | Where-Object {$_.Type -eq 'tEXt'} | Select-Object -First 1 | Select-Object -ExpandProperty Data_raw
[System.Text.Encoding]::ASCII.GetString($textChunk)

# Get integer
[byte[]]$dataChunk = $res | Where-Object {$_.Type -eq 'IHDR'} | Select-Object -ExpandProperty Data_raw
$width = $dataChunk[0..3]
[array]::Reverse($width)
[System.BitConverter]::ToUInt32($width,0)

# Get file attributes (using cast)
$lnkFile = 'C:\Users\ojk\Desktop\Atom.lnk'
$fs = New-Object -TypeName System.IO.FileStream -ArgumentList ($lnkFile, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read)
$br = New-Object -TypeName System.IO.BinaryReader -ArgumentList $fs
$br.BaseStream.Position = 24

$fa = $br.ReadUInt32()
$fa

[System.IO.FileAttributes]$fileAttributes = $fa
$fileAttributes

# Get file date
$creationTimeRaw = $br.ReadUInt64()
$creationTimeRaw
$creationTime = [datetime]::FromFileTime($creationTimeRaw)
$creationTime

# Be careful though! If you don't read the correct bytes it will fail or give you wrong data!
$br.BaseStream.Position = 26
$creationTimeRaw = $br.ReadUInt64()
$creationTime = [datetime]::FromFileTime($creationTimeRaw)
$creationTime