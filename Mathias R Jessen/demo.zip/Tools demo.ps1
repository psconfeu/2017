﻿# Tool making

# generic replace functions
# http://stackoverflow.com/questions/30778098/find-and-replace-special-characters-powershell/30778210#30778210

function Replace-SpecialChars {
    param($InputString)

    $SpecialChars = '[#?\{\[\(\)\]\}]'
    $Replacement  = '_A'

    $InputString -replace $SpecialChars,$Replacement
}

# Unsure what to escape? Ask the regex engine!
function Replace-SpecialChars {
    param(
        [string]$InputString,
        [string]$Replacement  = "_A",
        [string]$SpecialChars = "#?()[]{}"
    )

    $rePattern = ($SpecialChars.ToCharArray() |ForEach-Object { [regex]::Escape($_) }) -join "|"

    $InputString -replace $rePattern,$Replacement
}




# Abstract tools for finding patterns
# http://stackoverflow.com/questions/43450914/how-to-use-findstr-in-powershell-to-find-lines-where-all-words-in-the-search-str/43451196#43451196

# Q: How can I test if input contains ANY of X strings, (ex: word1 word2 word3)
# A: Easy! Use the OR operator "|":
"This string contains word2 but none of the others" -match '\b(?:word1|word2|word3)\b'

# Q: How can I test if input contains ALL of X strings, (ex: word1 word2 word3)
# A: Easy if in expected order:
"This string contains word1 and word2 and even word3" -match '\bword1.*word2.*word3\b'

# What if in any order?
"This string contains word2 word1 and word3 but in wrong order" -match 'word1.*word2.*word3' # oh shit!

# Assertions to the rescue!
"This string contains word2 word1 and word3 but in wrong order" -match '^(?=.*\bword1\b)(?=.*\bword2\b)(?=.*\bword3\b).*$'

<#
    ^(?=.*\bword1\b)(?=.*\bword2\b)(?=.*\bword3\b).*$
    ^              # start of string  
     (?=           # open positive lookahead assertion containing
        .*         # any number of any characters (like * in wildcard matching)
          \b       # word boundary
            word1  # the literal string "word1"
          \b       # word boundary
     )             # close positive lookahead assertion
     ...           # repeat for remaining words
     .*            # any number of any characters
    $              # end of string
#>

function Match-AnyOrder 
{
    param(
        [string]$inputString,
        [string[]]$terms
    )
    $template = '^{0}.*$'
    $termTemplate = '(?=.*\b{0}\b)'

    $TermAssertions = $terms.ForEach({$termTemplate -f [regex]::Escape($_)}) -join ''
    $pattern = $template -f $TermAssertions
    Write-Host "$pattern"
    $inputString -match $pattern
}

