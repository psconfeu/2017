﻿function New-ProxyCommand
{
    [CmdletBinding(DefaultParameterSetName='Name')]
    param(
        [Parameter(Mandatory=$true,ValueFromPipeline=$true,ParameterSetName='Command')]
        [System.Management.Automation.CommandInfo]$Command,

        [Parameter(Mandatory=$true,ParameterSetName='Name')]
        [string]$Name
    )

    if($PSCmdlet.ParameterSetName -eq 'Name'){
        try{
            $Command = Get-Command $Name
        }
        catch {
            throw $_
            return
        }
    }

    # Create Command metadata object
    $cmdMeta = [System.Management.Automation.CommandMetadata]::new($Command)

    # Emit proxy command
    return [System.Management.Automation.ProxyCommand]::Create($cmdMeta)
}