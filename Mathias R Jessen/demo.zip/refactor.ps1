﻿function Invoke-NamespaceRefactoring
{
    param(
        [string]$InputString,
        [string[]]$Namespaces = @(
            'System.Management.Automation.Language',
            'System.Collections.Generic',
            'System'
        )
    )

    # Define pattern for finding fully qualified type names
<#
(?<=          # positive lookbehind for
    [,\[\]]    # ,[]
    |          # OR
    \:\s*      # : 
)             # end lookbehind
{0}\.(\w+)    # $Namespace.$Typename (capture $Typename)
(?=           # positive lookahead for
   [,\[\]]     # ,[]
   |           # OR
   \s*         # optional whitespace
)             # end lookahead
#>

    # Define a pattern for finding fully qualified type names
    $PatternTemplate = @'
(?<=          
    [,\[\]]   
    |         
    \:\s*     
)             
{0}\.(\w+)    
(?=           
   [,\[\]]    
   |          
   \s*
)             
'@ 

    # Remove whitespace characters not preceded by an odd number of backslashes
    $PatternTemplate = $PatternTemplate -replace '(?<!\\(\\\\)*)\s+'

    $UsingStatements = foreach($Namespace in $Namespaces) {
        # Populate pattern with $Namespace 
        $Pattern = $PatternTemplate -f [regex]::Escape($Namespace)
        # Replace namespace prefixes
        $InputString = $InputString -replace $Pattern,'$1'
        if($Namespace -ne 'System'){
            # Output 'using namespace' statement (except for System, implied)
            'using namespace {0}' -f $Namespace
        }
    }

    # Return new script 
    return @($UsingStatements;$InputString) -join [Environment]::NewLine
}