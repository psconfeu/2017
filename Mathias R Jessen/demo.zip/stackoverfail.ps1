﻿# Compile test application
Add-Type -TypeDefinition @'
using System.Diagnostics;
using System.IO;
using System.Linq;

class Program
{
    // http://stackstatus.net/post/147710624694/outage-postmortem-july-20-2016 
    static void Main(string[] args)
    {
        string input;
        if(args.Length > 0 && File.Exists(args[0]))
            input = File.ReadAllLines(args[0]).First();
        else
            input = File.ReadAllLines(@"failstring.txt").First();

        // Original SE regex approach
        Stopwatch sw = Stopwatch.StartNew();
        string outputFail = System.Text.RegularExpressions.Regex.Replace(input, @"^[\s\u200c]+|[\s\u200c]+$", "");
        sw.Stop();
        System.Console.WriteLine("Fail regex  :  {0,7}ms ({1} ticks)", sw.ElapsedMilliseconds, sw.ElapsedTicks);

        // String.Trim() with all chars from [\s\u200c]
        sw = Stopwatch.StartNew();
        char[] whitespace = new char[] { '\u0009', '\u000A', '\u000B', '\u000C', '\u000D', '\u0020', '\u0085', '\u00A0', '\u1680', '\u2000', '\u2001', '\u2002', '\u2003', '\u2004', '\u2005', '\u2006', '\u2007', '\u2008', '\u2009', '\u200A', '\u200C', '\u2028', '\u2029', '\u202F', '\u205F', '\u3000' };
        string outputTrim = input.Trim(whitespace);
        sw.Stop();
        System.Console.WriteLine("String.Trim :  {0,7}ms ({1} ticks)", sw.ElapsedMilliseconds,sw.ElapsedTicks);
    }
}
'@ -OutputAssembly .\stackoverfail.exe -OutputType ConsoleApplication

# Download malformed input file
[System.Net.WebClient]::new().DownloadFile("https://gist.githubusercontent.com/IISResetMe/778700ac753017b4fd72a619d8d70a99/raw/a28c7045c03603843c526844760d62b037506a8b/failstring.txt","$PWD\failstring.txt")

# Run sample
& .\stackoverfail.exe