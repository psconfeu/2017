﻿# Sorting and Grouping

# Sorting by letters, then numbers
# http://stackoverflow.com/questions/41408094/how-to-sort-string-array-first-by-letter-then-by-number-combination/41408200#41408200

# Q: I have a list of strings containing letters and numbers
#    I wan't to sort alphabetically first, and then 
$list = 'aa101','aa11','ab10','ab9','a111','a22','a01'

# Construct term with no numbers, then with only digits 
$list |Sort-Object -Property {"$_" -replace '\d'},{"$_" -replace '\D'}

# What's with the last two?
$list |Sort-Object {"$_" -replace '\d'},{("$_" -replace '\D') -as [int]}

# Similarly with Group-Object
$list |Group-Object {"$_" -replace '\D'} # no need to cast as int, Group-Object groups on strings anyway



# Split ambigous hyphens
$InputStrings = '8-12','-4--2'

$InputStrings[0] -split '-'
$InputStrings[1] -split '-'

$InputStrings[0] -split '(?<=\d)-'
$InputStrings[1] -split '(?<=\d)-'



# Extracting Operating System version
# http://stackoverflow.com/questions/33973792/regex-to-extract-number-from-string-gwmi-win32-operatingsystem-name/33973981#33973981
(Get-CimInstance Win32_OperatingSystem).Name |Tee-Object -Variable OSName

# Split by |
$OSName -split '|'

# Escape!
$OSName -split '\|'

# Grab first part
$OSVersionName = $OSName -split '\|' |Select-Object -First 1

# Replace everything but version number
$OSVersionName -replace '\D+(\d+)\D*','$1'

# Alternative one-off pattern
$OSName -replace '\D+(\d+(?:\.\d))\D*\|.*$','$1'




# Matching IPv4 addresses
# Real IPv4 address pattern:
# ^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$

# Input strings
$InputStrings = '10.0.0.1','172.17.34.93','23.340.1.20'

# Check to see if they match our expected pattern
$NaiveIPv4Pattern = '^(\d{1,3}\.){3}\d{1,3}$'
$PotentialIPs = $InputStrings -match $NaiveIPv4Pattern 

# Invalid IP address! What gives?!
$ActualIPs = $PotentialIPs.ForEach({$_ -as [ipaddress]}).Where({$_}).IPAddressToString




# Renaming files
# http://stackoverflow.com/questions/41226456/replace-folder-name-with-characters-in-parentheses/41228269#41228269
Get-ChildItem .\folders -Directory |Where-Object {$_.Name -match '^\w+\(\d+\)'} |Rename-Item -NewName {$_.Name -replace '^\w+\((\d+)\)$','$1'} -WhatIf

# No need to filter first
# If -replace pattern doesn't match, resulting NewName will just be the existing name
Get-ChildItem .\folders -Directory |Rename-Item -NewName {$_.Name -replace '^\w+\((\d+)\)$','$1'}




# Dynamic substring with -replace 
# http://stackoverflow.com/questions/42435575/get-string-length-that-is-created-dynamically/42435701#42435701

# Original question
$string = 'arbitrary string' # << is random
(Do-Something -Name ($string + (Get-Random)).Substring(0, [math]::Min(20, ??)

# Terse example with Substring and Math.Max, one statement
Do-Something -Name ($s = $string + (Get-Random)).Substring(0, [math]::Min(20,$s.Length))

# Less terse
$Name = $string + (Get-Random)
if($Name.Length -gt 20){
    $Name = $Name.Substring(0, 20)
}
Do-Something -Name $Name

# Let's see if Regex can do this
$Name = "$string$(Get-Random)" -replace '^(.{20}).+$','$1'
# Same as above, if string length is -lt 20, it won't match and you just get the string
