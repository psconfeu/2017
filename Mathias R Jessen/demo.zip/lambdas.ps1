﻿# Replace depending on match length
# http://stackoverflow.com/questions/38674494/replace-leading-zeros-with-spaces/38674521#38674521

# Q:
# A record will look like this:
#
#     A206   000001204   X4609
#
# I need the record to look like this:
#
#     A206        1204   X4609
#
# I'm extremely unfamiliar with regex but the following regex seems to find the matches that I need:
#
#     \b0+

$inputString = 'A206   000001204   X4609'
$inputString -replace '\b0+','     '

$inputString = 'A206   000021204   X4609'
$inputString -replace '\b0+','     '





# Use a MatchEvaluator!
$inputString = 'A206   000001204   X4609'
[regex]::Replace($inputString, '\b0+', {param($m) ' ' * $m.Value.Length})

$inputString = 'A206   000021204   X4609'
[regex]::Replace($inputString, '\b0+', {param($m) ' ' * $m.Value.Length})
