## Test Cases and Tags

cd 'Presentations:\PSConfEU2017 - Green is Bad Red is Good'
cls 
Invoke-Pester -Tag Backup

cls
Invoke-Pester -tag Collation

cls
Invoke-Pester -Tag DBCC

cls
Invoke-Pester -Tag Server

cls
Invoke-Pester