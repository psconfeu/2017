﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

param (
$ItemID,
$FirstName,
$LastName,
$Initials,
$Password
)

$UsageLocation= "DK"
$OrganizationalUnit = "OU=Users,OU=HQ,DC=cloud,DC=local"
$MailDomain = "runbook.guru"
    
#Update Sharepoint
.\Update-SPOnlineItemScript.ps1 `
		-ListName "New User" `
		-ListItemId $ItemID `
		-Values @{"Status" = "In Progress"}

try {	

    .\New-O365User.ps1 -OrganizationalUnit $OrganizationalUnit -FirstName $FirstName -LastName $LastName -MailDomain $MailDomain -Initials $Initials -Password $Password 

	#Update Sharepoint
	.\Update-SPOnlineItemScript.ps1 `
			-ListName "New User" `
			-ListItemId $ItemID `
			-Values @{"Status" = "Completed"
						"Result" = "User Created"}
}
catch
{
	#Update Sharepoint
	.\Update-SPOnlineItemScript.ps1 `
			-ListName "New User" `
			-ListItemId $ItemID `
			-Values @{"Status" = "Failed"
				"Result" = $_}
	Write-Error $_
}

