﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

param($MobilePhone)

$UserAD = get-aduser -Filter "MobilePhone -eq '$MobilePhone'" -Properties MobilePhone
$UserAD | Unlock-ADAccount 

