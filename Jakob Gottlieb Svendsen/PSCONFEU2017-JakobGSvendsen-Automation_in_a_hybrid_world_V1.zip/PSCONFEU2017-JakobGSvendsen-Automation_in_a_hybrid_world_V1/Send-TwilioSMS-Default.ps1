﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

Param($To, $Message)

$Connection = Get-AutomationConnection -Name 'Twilio Demo'
#$from = "+12565105545" #Twilio phone number

$from = "+46769446698" #Twilio phone number

Send-TwilioSMS -Connection $Connection -from $from -to $To -Message $Message

