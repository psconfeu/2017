﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

param($webhookdata)

$webhookdata