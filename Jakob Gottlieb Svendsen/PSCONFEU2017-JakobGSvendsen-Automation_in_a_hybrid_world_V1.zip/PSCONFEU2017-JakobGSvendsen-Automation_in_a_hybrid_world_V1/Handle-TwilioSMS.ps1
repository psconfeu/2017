﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

param($WebhookData)
$ErrorActionPreference = "Stop"
	
$TwilioData = [System.Web.HttpUtility]::ParseQueryString($webhookdata.RequestBody)

$From = $TwilioData["From"]
$Body = $TwilioData["Body"]

Switch -Wildcard ($body.Trim())
{
    "UNLOCK" {
                .\Unlock-ADAccountByMobileNumber.ps1 -MobilePhone $From
				.\Send-TwilioSMS-Default.ps1 -to $From -Message "Your account has been unlocked" 
    }
    "RESET*" {
                .\New-SMSPasswordReset.ps1 -MobilePhone $From -NewPassword $body.Trim().Split(" ")[1]
    }
    default {
        .\Send-TwilioSMS-Default.ps1 -to $From -Message "$Body is not a supported function"
    }
}


