﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen, - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

param($webhookdata)

$ErrorActionPreference="stop"
	
$Connection = Get-AutomationConnection -Name 'Twilio Demo'
$from = "+46769446698" #Twilio phone number

$Connection | ft 

# Get Webhook Data
$RequestBody = ConvertFrom-JSON $WebhookData.RequestBody

# Searching Webhook Data for Value Results
$SearchResults = $RequestBody.SearchResults
$SearchResultsValue = $SearchResults.value
Foreach ($item in $SearchResultsValue)
{
    $UserName = $item.TargetUserName

    $UserAD = get-aduser -Filter "SamAccountName -eq '$UserName'" -Properties MobilePhone

    $to = $UserAD.MobilePhone
	
	Send-TwilioSMS -Connection $COnnection -from $from -to $to -Message "Your account has been locked. Please reply UNLOCK to unlock your account"
}

