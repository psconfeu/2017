﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [String] $OrganizationalUnit,
    [Parameter(Mandatory=$true)]
    [String] $FirstName,
    [Parameter(Mandatory=$true)]
    [String] $LastName,
    [Parameter(Mandatory=$true)]
    [String] $MailDomain,
    [Parameter(Mandatory=$true)]
    [String] $Initials,
    [Parameter(Mandatory=$true)]
    [String] $Password,
    [Parameter(Mandatory=$false)]
    [String] $UsageLocation= "DK"
)

$ErrorActionPreference = "stop"
<#
$OrganizationalUnit = "OU=Users,OU=HQ,DC=cloud,DC=local"
$FirstName = "Automate"
$LastName = "User01"
$MailDomain = "runbook.guru"
$Initials  = "A01"
$SamAccountName = $Initials
$Password = "Start123!"
$UsageLocation= "DK"
#>  

$MSOnlineLincenseName = "RunbookGuru:ENTERPRISEPACK"

$ADConnectServer = Get-AutomationVariable 'AD Connect Server' #"DC01.cloud.local" 

$ADConnectServerCredential = Get-AutomationPSCredential -Name 'AD Connect Server Admin Account' #New-Object -typename System.Management.Automation.PSCredential -argumentlist $username, $upassword

$MSOnlineCredential = Get-AutomationPSCredential -Name 'Office 365 Admin Account' #New-Object -typename System.Management.Automation.PSCredential -argumentlist $username, $upassword

$SamAccountName = $Initials
$UserPrincipalName = "$Initials@$MailDomain"
    
#$Password = ConvertTo-SecureString -String $Password -AsPlainText -Force 

$NewUser = New-ADUser -Name "$FirstName $LastName" -GivenName $FirstName -Surname $LastName  -AccountPassword (ConvertTo-SecureString -String $Password -AsPlainText -Force ) -Initials $Initials  -SamAccountName $SamAccountName  -UserPrincipalName $UserPrincipalName -Path $OrganizationalUnit -PassThru 
    
Enable-ADAccount -Identity $NewUser.DistinguishedName

#Trigger AD connect delta sync
Write-Output "Triggering AD Connect sync"
Invoke-Command -ComputerName $ADConnectServer -Credential $ADConnectServerCredential { & "C:\Program Files\Microsoft Azure AD Sync\Bin\DirectorySyncClientCmd.exe" "delta" } 

#Wait for user to sync into Azure AD
Connect-MsolService -Credential $MSOnlineCredential
$User = $null
$bFirst = $true
Do {
    
    if(!$bFirst) {
        Write-Output "Waiting 10 seconds for user: $UserPrincipalName"
        Start-Sleep -Seconds 10
    }
    $User = Get-MsolUser -UserPrincipalName $UserPrincipalName -ErrorAction Continue
    $bFirst = $false
} Until ($User)

Write-output "Found user"

Write-output "Setting Usage Location on user"
Set-MsolUser -UserPrincipalName $UserPrincipalName -UsageLocation $UsageLocation 

Write-Output "Adding License"
Set-MsolUserLicense -UserPrincipalName $UserPrincipalName -AddLicenses $MSOnlineLincenseName 


