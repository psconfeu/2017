﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen, - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

 param([object]$WebhookData)

 <#Debugging
 $WebhookData = ConvertFrom-Json @"
{"WebhookName":"SharePoint Graph API","RequestBody":"{\"value\":[{\"subscriptionId\":\"24ab4a7e-5792-49f2-a262-dab91deaca1d\",\"subscriptionExpirationDateTime\":\"2017-05-01T07:50:07.7802337+00:00\",\"changeType\":\"created\",\"resource\":\"Users/2c1bffd6-4129-4683-9bfa-7edee2d245e8/Messages/AAMkADEzNzUwOGFhLTZiMTAtNDE0OS1iMzc0LTZiNWM5ZmYzMWVmOQBGAAAAAACQcvdkZ1TrSpAU1O8LWfSKBwAXfn5ztDB0Q4By5ap1_hjPAAAAAAEMAAAXfn5ztDB0Q4By5ap1_hjPAAJesZu1AAA=\",\"resourceData\":{\"@odata.type\":\"#Microsoft.Graph.Message\",\"@odata.id\":\"Users/2c1bffd6-4129-4683-9bfa-7edee2d245e8/Messages/AAMkADEzNzUwOGFhLTZiMTAtNDE0OS1iMzc0LTZiNWM5ZmYzMWVmOQBGAAAAAACQcvdkZ1TrSpAU1O8LWfSKBwAXfn5ztDB0Q4By5ap1_hjPAAAAAAEMAAAXfn5ztDB0Q4By5ap1_hjPAAJesZu1AAA=\",\"@odata.etag\":\"W/\\\"CQAAABYAAAAXfn5ztDB0Q4By5ap1+hjPAAJe55bn\\\"\",\"id\":\"AAMkADEzNzUwOGFhLTZiMTAtNDE0OS1iMzc0LTZiNWM5ZmYzMWVmOQBGAAAAAACQcvdkZ1TrSpAU1O8LWfSKBwAXfn5ztDB0Q4By5ap1_hjPAAAAAAEMAAAXfn5ztDB0Q4By5ap1_hjPAAJesZu1AAA=\"},\"clientState\":\"DefaultClientState\"}]}","RequestHeader":{"Connection":"Keep-Alive","Host":"s1events.azure-automation.net","User-Agent":"Mozilla/5.0","x-ms-request-id":"49624393-4d18-4907-9e89-ddad586dce72"}}
"@
#>
$ErrorActionPreference = "Stop"
	
# Collect properties of WebhookData
$WebhookName    =   $WebhookData.WebhookName
$WebhookHeaders =   $WebhookData.RequestHeader
$WebhookBody    =   $WebhookData.RequestBody

$Body = ConvertFrom-Json -InputObject $WebhookBody

$clientId = "cdec3c46-b1cd-4ce7-859a-b6fac1ce0b3e"
$redirectUri = "http://www.runbook.guru"
$cred = Get-AutomationPSCredential -Name 'Office 365 Admin Account'
$Token = Get-GraphAuthToken -AADTenant "runbookguru.onmicrosoft.com" -ClientId $clientId -RedirectUri $redirectUri  -Credential $cred
$Mail = Invoke-GraphRequest -Token $Token -Method Get -url "https://graph.microsoft.com/beta/$($body.value.resourceData.'@odata.id')"

$EmailBody = $Mail.body.content

#Service Now
Import-Module PSServiceNow

$url = Get-AutomationVariable -Name 'ServiceNow URL'
$cred = Get-AutomationPSCredential -Name 'ServiceNow Service Account'

write-output "Connect Service Now: $url"
Set-ServiceNowAuth -url $url -Credentials $cred

write-output "Create Service Now Incident"
$Incident = New-ServiceNowIncident -ShortDescription $Mail.Subject -Description $mail.Body -Caller $Mail.From.EmailAddress.Address -CustomFields @{'u_emailbody'=$EmailBody} 
if($null -eq $Incident)
{
    throw "Incident not received! Is the Service Now instance sleeping?"
}

write-verbose $Incident
$IncidentGuid = $Incident.sys_id
Write-output "Created: $($Incident.number)"

$Attachments = Invoke-GraphRequest -Token $Token -Method Get -url "https://graph.microsoft.com/beta/$($body.value.resourceData.'@odata.id')/attachments"
if($Attachments.value.Count -gt 0) {
 
write-output "Incident has $($Attachments.value.Count) attachments"
write-Verbose "Attachments:"
Write-Verbose ($Attachments.value | format-table name,@{l="Size (kb)";e={([Convert]::FromBase64String($PSItem.contentBytes)).Length /1KB };f="N2"} -autosize | Out-String)
  
$hasAttachments = $false
 foreach ($Attachment in $Attachments.value)
 {
   # $FileSize = ([Convert]::FromBase64String($Attachment.contentBytes)).Length
    
   # if($FileSize -lt 5MB)
   # {
        $hasAttachments = $true
        Write-output "$($Attachment.name): Uploading"
        $xml = @"
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ecc="http://www.service-now.com/ecc_queue">
        <soapenv:Header/>
            <soapenv:Body>
            <ecc:insert>
                <agent>AttachmentCreator</agent>
                <name>$($Attachment.name)</name>
                <payload>$($Attachment.contentBytes)</payload>;
                <source>incident:$IncidentGuid</source>
                <topic>AttachmentCreator</topic>
            </ecc:insert>
            </soapenv:Body>
        </soapenv:Envelope>
"@

        $URI = "https://$url/ecc_queue.do?SOAP"
        $resultXML =(Invoke-WebRequest $URI -Body $xml -ContentType "text/xml" -Method POST -UseBasicParsing -Credential $cred -TimeoutSec 300)

        $resulobj = [xml] $resultXML.Content
        $Objectid = $resulobj.Envelope.Body.insertResponse.sys_id
     <# }
      else
      {
        Write-Output "$($Attachment.name): File is too large (Maximum 5MB)"
        #TODO Add to incident log
      }#> 
 }

 if($hasAttachments)
 {
     write-output "Getting Attachment Ids"
     $Uri = $global:ServiceNowRESTURL + "/table/sys_attachment?table_sys_id=$IncidentGuid"
     $AttachmentsIncident = Invoke-RestMethod -Uri $uri -Method Get -Credential $global:ServiceNowCredentials #-Body $Body #-ContentType "application/json"

     $AttachedImages = $AttachmentsIncident.result | ? file_name -like "image*.png"
     if($AttachedImages.count -gt 0)
     {
         write-output "Replacing Email Body Images URIs"
         foreach ($AttachmentIncident in $AttachedImages)
         {
            $ImageNameEncoded = [System.Text.RegularExpressions.Regex]::Escape($AttachmentIncident.file_name)
            $EmailBody = $EmailBody  -replace "cid:$ImageNameEncoded\@.{8}\..{8}","/sys_attachment.do?sys_id=$($AttachmentIncident.sys_id)"
         }
      }
    }

   $values = @{"u_emailbody" = $EmailBody }
   $Body = $Values | ConvertTo-Json;

   Write-Output "Updating Incident Email Body"
   $Uri = $global:ServiceNowRESTURL + "/table/incident/$IncidentGuid"
   $result = Invoke-RestMethod -Uri $uri -Method Put -Credential $global:ServiceNowCredentials -Body $Body -ContentType "application/json" 

}
else
{
    write-output "Incident has no attachments"
} #Attachments

Write-output "Completed Successfully"


