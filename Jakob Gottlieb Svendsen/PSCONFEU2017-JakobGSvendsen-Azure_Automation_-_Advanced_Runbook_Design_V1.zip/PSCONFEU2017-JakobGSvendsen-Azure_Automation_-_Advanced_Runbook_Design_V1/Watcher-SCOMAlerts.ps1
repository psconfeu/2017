﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

Import-module OperationsManager
#States
$SCOMStateITSM = 1 #249 #Resolution state for sending to ITSM

#Get new Alerts
$SCOMEnvironments = 
@{
    Name="OMCloudMG"; 
    ServerName = "OM01"; 
    Credential = 'SCOM Service Account'
}
<#,
@{
    Name="OMCloudMG2"; 
    ServerName = "OM01"; 
    Credential = 'SCOM Service Account'
}#>

#Get Last Date and set current date
$lastdate =  Get-AutomationVariable -Name 'SCOM Monitor Last Run (Watcher)'
$currentdate = (Get-date).ToUniversalTime()
#write-verbose "Last Date: $lastdate"
#write-verbose "Current Date: $currentdate"

#Set last date
Set-AutomationVariable -Name 'SCOM Monitor Last Run (Watcher)' -Value $currentdate

Foreach($SCOMEnvironment in $SCOMEnvironments)
{

    $Name = $SCOMEnvironment.Name
    $SCOMServerName = $SCOMEnvironment.ServerName
    $CredentialName = $SCOMEnvironment.Credential

    write-verbose "$(Get-Date): Getting new alerts from $Name on MS: '$SCOMServerName' using Credential '$CredentialName'"

    $credSCOM = Get-AutomationPSCredential -Name $CredentialName
    $SCSession = New-SCOMManagementGroupConnection -ComputerName $SCOMServerName -Credential $credSCOM -PassThru
            
    #Get All changes alerts in specific resolution state or close within current time and last check TODO Add AND ResolutionState  = $SCOMStateITSM
    $alerts = Get-scomalert -SCSession $SCSession -Criteria "
    LastModified >= '$lastdate' AND LastModified <= '$currentdate' AND ResolutionState  = $SCOMStateITSM  AND (TicketId = '' OR TicketId IS NULL)"
    <# OR
    (LastModified >= '$lastdate' AND LastModified <= '$currentdate' AND ResolutionState  = 255)
    "#>

    Write-verbose "Processing $($alerts.Count) Alerts"
    If ($alerts) {
        $alerts = $alerts | select @{name="ManagementGroup";e={ $_.ManagementGroup.Name.ToString()}}, context,category,classid,customfield1,customfield2,customfield3,customfield4,customfield5,customfield6,customfield7,customfield8,customfield9,customfield10,description,id,monitoringobjectfullname,monitoringobjectid,monitoringobjectpath,name,netbioscomputername,owner,parameters,principalname,priority,repeatcount,resolutionstate,resolvedby,severity,sitename,timeraised,lastmodified,ticketid,timeresolutionstatelastmodified,timeresolved,monitoringobjectInmaintenancemode
       
       # foreach($alert in $alerts)
       # {
         #Trigger Action(s)           
          [hashtable]$properties = @{}
            $properties.alerts = "$($alerts | COnvertTo-JSON -Depth 1)"
        
            Invoke-AutomationWatcherAction -Message "New Alert" -CustomProperties $properties
       # }
    }   
} #Foreach Server


