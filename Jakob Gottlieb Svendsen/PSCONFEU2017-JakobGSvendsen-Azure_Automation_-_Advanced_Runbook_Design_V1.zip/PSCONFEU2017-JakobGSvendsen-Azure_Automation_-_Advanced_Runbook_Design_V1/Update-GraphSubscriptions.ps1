﻿# //*********************************************************************************************
# // ***** Script Header *****
# // Author:	Jakob Gottlieb Svendsen, Coretech A/S. http://blog.coretech.dk / www.runbook.guru
# //
# // History:
# // 0.0.1     JGS 15/05/2016  Created initial version.
# //
# // ***** End Header *****
# //********************************************************************************************
# //----------------------------------------------------------------------------

$ErrorActionPreference = "Stop"

$ListName = "Microsoft Graph Subscriptions"
$SPConnection = Get-AutomationConnection -Name "SharePoint Online Connection"
$Items = Get-SPListItem -SPConnection $SPConnection -ListName $ListName

#New items
foreach ($item in ($items | Where { !$PSItem.SubscriptionId -and !$PSItem.Disable } ) )
{
    Write-Output "Creating Subscription for $($Item.Resource)"
    #Logon Graph
    $GraphConnection = Get-AutomationConnection -Name $Item.CredentialName
    $Token = Get-GraphAuthToken -Connection $GraphConnection
    $result = $null
    $result = New-GraphSubscription -Token $Token -ResourceUri $Item.Resource -WebhookUri $Item.NotificationURL -ChangeType $item.ChangeType 
    $result 
    #update SharePoint
    $Values = @{
                "SubscriptionId" = $result.id 
                "SubscriptionLastUpdated" = (get-date).ToString("yyyy-MM-ddTHH:mm:ssZ")
                "SubscriptionExpiration" = $result.expirationDateTime
    }
    Update-SPListItem -SPConnection $SPConnection -ListName $ListName -ListItemID $Item.ID -ListFieldsValues $Values
}

#Items that needs update
foreach ($item in ($items | Where { $PSItem.SubscriptionId -and !$PSItem.Disable  } ) ) #-and $PSItem.SubscriptionExpiration -lt (get-date).AddHours(24) 
{
    Write-Output "Updating Subscription for $($Item.Resource) - SubscriptionId: $($Item.SubscriptionId)"
    #Logon Graph
    $GraphConnection = Get-AutomationConnection -Name $Item.CredentialName
    $Token = Get-GraphAuthToken -Connection $GraphConnection
    $result = $null
    $result = Update-GraphSubscription -Token $token -SubscriptionId $item.SubscriptionId
    $result 
    #update SharePoint
    $Values = @{
                "SubscriptionId" = $result.id 
                "SubscriptionLastUpdated" = (get-date).ToString("yyyy-MM-ddTHH:mm:ssZ")
                "SubscriptionExpiration" = $result.expirationDateTime
    }
    Update-SPListItem -SPConnection $SPConnection -ListName $ListName -ListItemID $Item.ID -ListFieldsValues $Values
}
Write-output "Disabled items: $(($items | Where {$PSItem.Disable } | Measure-Object).Count)"

write-output "Completed successfully"

break

#Remove-GraphSubscription -Token $token -SubscriptionId $result.id #bd16840e-28ce-4b1d-878d-59ad88b40f69
#Remove-GraphSubscription -Token $token -SubscriptionId 9e246fd0-ec6d-45db-a7d6-176f5097d5ab
#Remove-GraphSubscription -Token $token -SubscriptionId bd594b79-6038-403f-b9a7-e87233063314
#Remove-GraphSubscription -Token $token -SubscriptionId 6782cc69-9346-403b-b5e4-f787f1cffbde
#Setup Subscriptions
#$result = Invoke-GraphRequest -Token $Token -url "https://graph.microsoft.com/beta/me/messages" -Method Get
#$result.Value | Format-Table Subject,@{"label"="From";Expression={$_.From.emailAddress.address}} 