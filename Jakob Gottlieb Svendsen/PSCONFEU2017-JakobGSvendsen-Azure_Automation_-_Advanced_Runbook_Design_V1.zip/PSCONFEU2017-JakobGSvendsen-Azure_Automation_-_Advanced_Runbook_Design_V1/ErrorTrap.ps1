﻿$ErrorActionPreference = "stop"
trap [Exception] {  
    $ErrorMessage = "SCRIPT: SCSM-ImportData.ps1 failed`n"
    $ErrorMessage += "Runas user: $($env:username)`n"
    $ErrorMessage += "Script location: $PSScriptRoot`n`n"
    $ErrorMessage += "Error: Line,char: {0},{1} - Details: {2}" -f 
    $_.InvocationInfo.ScriptLineNumber,$_.InvocationInfo.OffsetInLine, 
    $_.Exception
    throw $ErrorMessage
    continue;
}


get-process test