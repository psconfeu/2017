﻿# //*********************************************************************************************
# // Author:	Jakob Gottlieb Svendsen, - Coretech Global. http://blog.coretech.dk
# // Contact:   @JakobGSvendsen
# // 0.0.1     JGS 05/05/2017  Created initial version.
# //********************************************************************************************

param(      
        [object]$EVENTDATA
)

$ErrorActionPreference = "stop"

#Assets
$Caller = Get-AutomationVariable -Name "ServiceNow Caller"
$url = Get-AutomationVariable -Name 'ServiceNow URL'
$cred = Get-AutomationPSCredential -Name 'ServiceNow Service Account'

#Get new Alerts
$SCOMEnvironments = 
@{
    Name="OMCloudMG"; 
    ServerName = "OM01"; 
    Credential = 'SCOM Service Account'
}
<#,
@{
    Name="OMCloudMG2"; 
    ServerName = "OM01"; 
    Credential = 'SCOM Service Account'
}#>

#Main
Get-Date
#$EVENTDATA
$Alerts = @()
$Alerts += $EVENTDATA.EventProperties.PropertyBag.Alerts | ConvertFrom-JSON
#$Alerts|  Format-Custom *
#$Alerts | ConvertTo-JSON
"Processing Alerts: {0}" -f $Alerts.Count 

#Service Now
Import-Module PSServiceNow
Import-module OperationsManager -verbose:$false

write-output "Connect Service Now: $url"
Set-ServiceNowAuth -url $url -Credentials $cred
write-output "Create Service Now Incident"

#Connect to SCOM Environmment
$credSCOM = Get-AutomationPSCredential -Name $SCOMEnvironment.Credential
$SCSession = New-SCOMManagementGroupConnection -ComputerName $SCOMEnvironment.ServerName -Credential $credSCOM -PassThru

Foreach($Alert in $Alerts) {
        #Get Alert
        $alertObject = Get-SCOMAlert -SCSession $SCSession  -Id $Alert.Id

    $Parameters = @{
        Caller = $Caller  
        Description = $Alert.Description
        ShortDescription = $Alert.Name
        CustomFields = $Fields
    }

    $Incident = $null
    $Incident = New-ServiceNowIncident @Parameters 
    if($null -eq $Incident)
    {
        $alertObject | Set-SCOMAlert -TicketId "Failed"
        throw "Incident not received! Is the Service Now instance sleeping?"
    }
    $Incident

    $SCOMEnvironment = $SCOMEnvironments | ? Name -eq $Alert.ManagementGroup
    
    #Set ticket ID
    $alertObject | Set-SCOMAlert -TicketId $Incident.number

    
}


